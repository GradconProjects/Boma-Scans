import test from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { fileURLToPath } from "node:url";
import path from "node:path";
import Module, { createRequire } from "node:module";
import ts from "typescript";

// Load the actual TypeScript engine without a browser or exchange connection.
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const require = createRequire(import.meta.url);
const modules = new Map();
function load(relative) {
  const filename = path.resolve(root, relative);
  if (modules.has(filename)) return modules.get(filename).exports;
  const module = new Module(filename);
  modules.set(filename, module);
  module.require = spec => spec.startsWith("@/") ? load(spec.slice(2) + ".ts") : require(spec);
  const output = ts.transpileModule(readFileSync(filename, "utf8"), {compilerOptions: {module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2022}});
  module._compile(output.outputText, filename);
  return module.exports;
}
const execution = load("app/lib/entry-execution.ts");
const policy = load("app/lib/entry-policy.ts");
const market = load("app/lib/market.ts");
const recommendations = load("app/lib/recommendations.ts");
const manager = load("app/lib/trade-manager.ts");
const leverage = load("app/lib/leverage.ts");
const signals = load("app/lib/signal-alerts.ts");
const confirmation = {mode: "STRICT", setupType: "PULLBACK", score: 76, threshold: 66, confluence: 3, frames: 2, plannedTriggerPassed: false, strongClose: true, structureReady: true, momentumAligned: true, notChased: true, invalidated: false};

function executionFixture(now = Date.now(), changes = {}) {
  const intervalMs = 300_000;
  const end = Math.floor(now / intervalMs) * intervalMs - intervalMs;
  const candles = Array.from({length:32}, (_,i) => ({time:end-(31-i)*intervalMs, open:100, high:100.5, low:99.5, close:100, volume:1000}));
  candles[candles.length-1] = {...candles.at(-1),open:100.1,low:99.9,high:100.5,close:100.35};
  const input = {candles,side:"LONG",marketPrice:100.3,zoneLow:100,zoneHigh:100.2,zoneSource:"Test retest",ema21:100,atr:1,intervalMs,now,mode:"STRICT",setupType:"PULLBACK",score:90,threshold:66,confluence:4,frames:3,strongClose:true,structureReady:true,momentumAligned:true,...changes};
  return {input,plan:execution.buildEntryExecutionPlan(input)};
}
function mirrorInput(input) {
  const mirror = bar => ({...bar,open:200-bar.open,high:200-bar.low,low:200-bar.high,close:200-bar.close});
  return {...input,side:"SHORT",marketPrice:200-input.marketPrice,zoneLow:200-input.zoneHigh,zoneHigh:200-input.zoneLow,ema21:200-input.ema21,candles:input.candles.map(mirror),liveCandle:input.liveCandle ? mirror(input.liveCandle) : undefined};
}

test("Planned timing cannot bypass the no-chase rule in any mode", () => {
  for (const mode of ["STRICT","BALANCED","FLEXIBLE"]) {
    assert.equal(policy.resolveEntryTiming({...confirmation,mode,plannedTriggerPassed:true,notChased:false}).passed,false);
  }
});
test("Normal confirmed retests remain actionable for both long and short", () => {
  const {input} = executionFixture();
  for (const side of [input,mirrorInput(input)]) {
    const plan = execution.buildEntryExecutionPlan(side);
    assert.equal(plan.status,"READY");
    assert.equal(plan.timingReady,true);
    assert.equal(execution.entryExecutionBlocker(plan,side.marketPrice,side.now),null);
    assert.equal(plan.steps.length,4);
    assert.match(plan.cancelText,/Never chase/);
  }
});
test("Pump/dump candles cannot confirm their own retest, even in Flexible mode", () => {
  const {input} = executionFixture();
  const pump = {...input.candles.at(-1),open:99.9,low:99.8,high:103.3,close:103.2};
  const pumped = {...input,candles:[...input.candles.slice(0,-1),pump],marketPrice:103.2,breakTime:pump.time,setupType:"BREAKOUT"};
  for (const mode of ["STRICT","BALANCED","FLEXIBLE"]) for (const scenario of [pumped,mirrorInput(pumped)]) {
    const plan = execution.buildEntryExecutionPlan({...scenario,mode});
    assert.equal(plan.status,"WAIT_RETEST");
    assert.equal(plan.timingReady,false);
    assert.equal(plan.impulsePending,true);
    assert.ok(execution.entryExecutionBlocker(plan,scenario.marketPrice,scenario.now,true));
  }
});
test("A pump can qualify only after a later retest and normal confirmation candle", () => {
  const {input} = executionFixture();
  const t = input.candles.at(-1).time;
  const bars = [...input.candles.slice(0,-1),
    {time:t,open:99.9,low:99.8,high:103.3,close:103.2,volume:2000},
    {time:t+300_000,open:103,low:100.05,high:103.1,close:100.4,volume:900},
    {time:t+600_000,open:100.15,low:100,high:100.55,close:100.4,volume:1100}];
  const recovered = {...input,candles:bars,now:t+901_000,marketPrice:100.4,ema21:100.5,breakTime:t,setupType:"BREAKOUT"};
  for (const scenario of [recovered,mirrorInput(recovered)]) {
    const plan = execution.buildEntryExecutionPlan(scenario);
    assert.equal(plan.status,"READY");
    assert.ok(plan.confirmationTime > t);
    assert.equal(plan.impulsePending,false);
  }
});
test("Quote-only chase never drags the zone/stop; failed reclaims and expiry block the click", () => {
  const {input,plan} = executionFixture();
  for (const source of [input,mirrorInput(input)]) {
    const baseline = execution.buildEntryExecutionPlan(source);
    const chase = source.side === "LONG" ? 102 : 98;
    const late = execution.buildEntryExecutionPlan({...source,marketPrice:chase});
    assert.equal(late.zoneLow,baseline.zoneLow);
    assert.equal(late.zoneHigh,baseline.zoneHigh);
    assert.equal(late.stop,baseline.stop);
    assert.equal(late.status,"WAIT_RETEST");
    assert.ok(execution.entryExecutionBlocker(baseline,chase,source.now));
    assert.ok(execution.entryExecutionBlocker(baseline,100,source.now));
    assert.ok(execution.entryExecutionBlocker(baseline,source.marketPrice,baseline.expiresAt));
  }
  assert.equal(execution.buildEntryExecutionPlan({...input,now:plan.expiresAt+1}).status,"EXPIRED");
});
test("Stop remains beyond full zone and retest wick; oversized structure is rejected", () => {
  const {input} = executionFixture();
  for (const source of [input,mirrorInput(input)]) {
    const wide = {...source, zoneLow:source.side === "LONG" ? 95 : source.zoneLow,zoneHigh:source.side === "SHORT" ? 105 : source.zoneHigh};
    const plan = execution.buildEntryExecutionPlan(wide);
    assert.ok(source.side === "LONG" ? plan.stop < 95 : plan.stop > 105);
    assert.equal(plan.status,"BLOCKED");
  }
});
test("An unfinished candle cannot supply confirmation and a pre-entry stop sweep cancels", () => {
  const {input,plan} = executionFixture();
  const notConfirmed = {...input,candles:input.candles.map(bar=>({...bar,open:100,close:100})),liveCandle:{time:input.candles.at(-1).time+300_000,open:100,low:99.9,high:100.5,close:100.4,volume:10}};
  assert.notEqual(execution.buildEntryExecutionPlan(notConfirmed).status,"READY");
  const swept = {...input,liveCandle:{...input.candles.at(-1),time:input.candles.at(-1).time+300_000,low:plan.stop-.1}};
  assert.equal(execution.buildEntryExecutionPlan(swept).status,"INVALIDATED");
  assert.equal(execution.buildEntryExecutionPlan(mirrorInput(swept)).status,"INVALIDATED");
});

test("Strict waits; Balanced accepts strong confirmation at threshold + 6", () => {
  assert.equal(policy.resolveEntryTiming(confirmation).passed, false);
  assert.equal(policy.resolveEntryTiming({...confirmation, mode: "BALANCED", score: 72}).passed, true);
  assert.equal(policy.resolveEntryTiming({...confirmation, mode: "BALANCED", score: 71}).passed, false);
});
test("Flexible continuation does not bypass momentum, structure, alignment or invalidation", () => {
  const input = {...confirmation, mode: "FLEXIBLE", setupType: "BREAKOUT", threshold: 70, score: 70};
  assert.equal(policy.resolveEntryTiming(input).passed, true);
  for (const bad of [{momentumAligned: false}, {structureReady: false}, {strongClose: false}, {notChased: false}, {frames: 1}, {confluence: 2}, {invalidated: true}]) assert.equal(policy.resolveEntryTiming({...input, ...bad}).passed, false);
});
test("All modes preserve a valid planned trigger and reject an invalidated plan", () => {
  for (const mode of ["STRICT", "BALANCED", "FLEXIBLE"]) {
    assert.equal(policy.resolveEntryTiming({...confirmation, mode, plannedTriggerPassed: true}).passed, true);
    assert.equal(policy.resolveEntryTiming({...confirmation, mode, plannedTriggerPassed: true, invalidated: true}).passed, false);
  }
});
test("Risk bands use exact shared cutoffs; BTC caution cannot be LOW", () => {
  const input = {entryReady: true, rating: 84, entryQuality: 84, regime: "TRENDING", targetReliability: 65, btcVerdict: "ACCEPT", requiredFailure: false, override: false};
  assert.equal(policy.relativeRiskBand(input), "LOW");
  assert.equal(policy.relativeRiskBand({...input, btcVerdict: "CAUTION"}), "MEDIUM");
  assert.equal(policy.relativeRiskBand({...input, rating: 70, entryQuality: 68, entryReady: false}), "MEDIUM");
  for (const bad of [{rating: 69}, {entryQuality: 67}, {regime: "VOLATILE"}, {requiredFailure: true}, {btcVerdict: "REJECT"}]) assert.equal(policy.relativeRiskBand({...input, ...bad}), "HIGH");
});

function fixture(symbol = "ETHUSDT", inverse = false) {
  const source = market.generateDemoCandles(symbol, "15", 480);
  const candles = inverse ? source.map(c => ({...c, open: 1e6/c.open, close: 1e6/c.close, high: 1e6/c.low, low: 1e6/c.high})) : source;
  const price = candles.at(-1).close;
  const ticker = market.normalizeTicker({symbol, lastPrice: price, markPrice: price, turnover24h: 500_000_000, bid1Price: price * .99999, ask1Price: price * 1.00001});
  return {candles, ticker};
}
test("Five target slots stay directional and ordered across styles, modes and long/short markets", () => {
  const seenSides = new Set();
  for (const inverse of [false, true]) for (const symbol of ["BTCUSDT", "ETHUSDT", "SOLUSDT", "ADAUSDT", "XRPUSDT", "LINKUSDT", "AVAXUSDT", "DOGEUSDT"]) {
    const {candles, ticker} = fixture(symbol, inverse);
    for (const mode of ["STRICT", "BALANCED", "FLEXIBLE"]) for (const style of ["SCALP", "DAY", "SWING", "POSITION"]) {
      const result = market.analyzeMarket(candles, candles, candles, ticker, style, {flexibility: mode});
      seenSides.add(result.bias);
      assert.ok(result.riskMultiplier >= .25 && result.riskMultiplier <= 1);
      for (const [entry, targets] of [[result.entry, result.takeProfits], [result.immediateEntry.entry, result.immediateEntry.targets]]) {
        assert.equal(targets.length, 5);
        assert.equal(targets.reduce((sum,tp) => sum + tp.exitPct,0), 100);
        let previous = entry;
        for (const tp of targets) {
          assert.ok(Number.isFinite(tp.price) && tp.price > 0);
          assert.ok(result.bias === "LONG" ? tp.price > previous : tp.price < previous);
          previous = tp.price;
          if (tp.level <= 3 && tp.available) assert.ok(!/ATR|volatility map/i.test(tp.source));
        }
      }
      if (result.entryReady) assert.ok(result.entryChecks.every(check => !check.required || check.status === "PASS"));
    }
  }
  assert.deepEqual([...seenSides].sort(), ["LONG", "SHORT"]);
});
test("Unconfirmed targets and insufficient history never authorize entries", () => {
  const {candles, ticker} = fixture();
  const result = market.analyzeMarket(candles.slice(-10), [], [], ticker, "DAY", {flexibility: "FLEXIBLE"});
  assert.equal(result.entryReady, false);
  assert.equal(result.immediateEntry.status, "AVOID");
  assert.equal(result.entryChecks.find(check => check.id === "history").status, "FAIL");
});
test("Full market analysis blocks quote-only pump/dump entries in both execution modes", () => {
  for (const inverse of [false,true]) {
    const {candles,ticker} = fixture("ETHUSDT",inverse);
    const first = market.analyzeMarket(candles,candles,candles,ticker,"DAY",{flexibility:"FLEXIBLE"});
    const price = first.bias === "LONG" ? Math.max(first.executionPlan.entryHigh, first.entry) + 6*first.metrics.atr : Math.min(first.executionPlan.entryLow, first.entry) - 6*first.metrics.atr;
    const late = market.analyzeMarket(candles,candles,candles,{...ticker,lastPrice:price,bid1Price:price*.99999,ask1Price:price*1.00001},"DAY",{flexibility:"FLEXIBLE"});
    assert.equal(late.entryReady,false);
    assert.equal(late.immediateEntry.status,"AVOID");
    assert.equal(late.executionPlan.zoneLow,first.executionPlan.zoneLow);
    assert.equal(late.executionPlan.zoneHigh,first.executionPlan.zoneHigh);
    assert.equal(late.stop,first.stop);
    assert.ok(late.entryChecks.find(check=>check.id==="trigger").status !== "PASS");
  }
});
test("Close-target payoff accounts for round-trip fees and slippage", () => {
  const {candles, ticker} = fixture();
  const cheap = market.analyzeMarket(candles, candles, candles, ticker, "SCALP", {takerFeePct: 0, slippagePct: 0}).immediateEntry;
  const costly = market.analyzeMarket(candles, candles, candles, ticker, "SCALP", {takerFeePct: .3, slippagePct: 1}).immediateEntry;
  assert.ok(costly.netRewardR < cheap.netRewardR);
  assert.equal(costly.status, "AVOID");
});
test("BTC correlation requires timestamp-aligned history, never array-position substitution", () => {
  const {candles, ticker} = fixture();
  const analysis = market.analyzeMarket(candles, candles, candles, ticker);
  const mismatch = candles.map(c => ({...c, time: c.time + 1}));
  const result = market.analyzeBtcRelationship("ETHUSDT", candles, mismatch, analysis);
  assert.equal(result.correlation, null);
  assert.equal(result.divergenceVerdict, "CAUTION");
  assert.equal(result.historyBars, 0);
  assert.ok(market.analyzeBtcRelationship("ETHUSDT", candles, candles, analysis).correlation > .99);
});
test("Shortlist rejects stale rows, missing instrument rules and required failures", () => {
  const row = {price:100.3, executionPlan: executionFixture().plan, analyzedAt: Date.now(), exchangeMaxLeverage: 10, quantityStep: .001, style: "DAY", demo: false, decision: "SETUP", entryReady: true, direction: "LONG", score: 90, setupThreshold: 70, entryQuality: 84, ratingScore: 84, entryChecks: [], riskBand: "LOW", btcRelationship: {divergenceVerdict: "ACCEPT"}, rr: 3, netRewardR: 3, targetReliability: 70, structuralTargets: 3, executionCostR: .01, spreadCostLimitR: .2, turnover: 500_000_000, trendFrames: 3, regime: "TRENDING"};
  assert.equal(recommendations.isMediumRiskTake(row, true), true);
  for (const bad of [{analyzedAt: Date.now() - 61 * 60_000}, {exchangeMaxLeverage: undefined}, {entryChecks: [{required:true,status:"FAIL"}]}, {btcRelationship: {divergenceVerdict:"REJECT"}}, {ratingScore:69}, {entryQuality:67}]) assert.equal(recommendations.isMediumRiskTake({...row,...bad}, true), false);
});
function trade(overrides = {}) {
  return manager.createTrackedTrade({symbol:"BTCUSDT", side:"LONG", mode:"PAPER", style:"DAY", entryPrice:100, quantity:1, leverage:5, stop:99, tp1:101, tp2:102, tp3:103, tp4:104, tp5:105, atrAtEntry:1, ...overrides});
}
test("Frozen targets and close-target weights survive storage; partial fills are idempotent", () => {
  const source = fixture();
  const analysis = market.analyzeMarket(source.candles,source.candles,source.candles,source.ticker);
  const snapshot = {entryMode:"MARKET", flexibility:"FLEXIBLE", score:85, entryQuality:85, btcVerdict:"ACCEPT", overrideAccepted:false, targets:analysis.takeProfits, reasons:["Confirmed"]};
  const position = trade({targetWeights:[30,25,20,15,10], entrySnapshot:snapshot});
  const original = position.entrySnapshot.targets[0].price;
  snapshot.targets[0].price = 1;
  assert.equal(position.entrySnapshot.targets[0].price, original);
  const restored = manager.parseStoredTrades(JSON.stringify([position]))[0];
  assert.deepEqual(restored.targetWeights, [30,25,20,15,10]);
  const partial = manager.applyPartialExit(restored,1,101);
  assert.equal(partial.remainingPct,70);
  assert.equal(manager.applyPartialExit(partial,1,101).remainingPct,70);
  assert.equal(manager.applyPartialExit(partial,5,105).status,"CLOSED");
});
test("Legacy trades remain readable; corrupt storage cannot crash the journal", () => {
  assert.equal(manager.parseStoredTrades(JSON.stringify([trade()])).length, 1);
  assert.deepEqual(manager.parseStoredTrades("{bad"), []);
  assert.equal(manager.parseStoredTrades(JSON.stringify([{...trade(),entrySnapshot:{targets:[null],reasons:[{}]}}]))[0].entrySnapshot, undefined);
});
test("Leverage changes margin, not chosen stop risk; portfolio and stale-quote guards remain", () => {
  for (const exchangeMaxLeverage of [1,3,10,100]) {
    const plan = leverage.buildAdaptiveLeveragePlan({accountEquity:1000,targetRiskPct:.5,entry:100,stop:99,score:95,regime:"TRENDING",trendFrames:3,atrPct:1,adx:30,style:"DAY",actionable:true,exchangeMaxLeverage,quantityStep:.001,minOrderQty:.001,minNotionalValue:5});
    assert.ok(plan.actualRiskPct <= .5 + 1e-9);
    assert.ok(plan.recommendedLeverage <= exchangeMaxLeverage);
  }
  assert.equal(manager.getPortfolioGuard([trade(),trade(),trade()],1000).blocked,true);
  assert.equal(manager.getPortfolioGuard([trade({quantity:30})],1000).blocked,true);
  assert.equal(manager.evaluateTrade(trade(),102,Date.now()-30_000,null).action,"DATA STALE");
});
test("Small gains and TP1 touches no longer force breakeven; partial advice uses frozen weights", () => {
  const now = Date.now();
  for (const side of ["LONG","SHORT"]) {
    const short = side === "SHORT";
    const position = trade({side,stop:short?101:99,tp1:short?99:101,tp2:short?98:102,tp3:short?97:103,tp4:short?96:104,tp5:short?95:105,targetWeights:[30,25,20,15,10]});
    const before = manager.evaluateTrade(position,short?99.2:100.8,now,null,now);
    assert.equal(before.suggestedStop,position.stop);
    assert.equal(before.action,"HOLD TO PLAN");
    const tp1 = manager.evaluateTrade(position,short?99:101,now,null,now);
    assert.equal(tp1.action,"TAKE PARTIAL");
    assert.equal(tp1.suggestedStop,position.stop);
    assert.match(tp1.detail,/30%/);
    assert.doesNotMatch(tp1.detail,/then move.*breakeven/);
  }
});
test("Profit protection needs later structure, never loosens a stop, and ignores stale data", () => {
  const now = Date.now();
  const {candles,ticker} = fixture();
  const analysis = market.analyzeMarket(candles,candles,candles,ticker);
  for (const side of ["LONG","SHORT"]) {
    const short = side === "SHORT";
    const position = {...trade({side,entryPrice:100,stop:short?101:99,tp1:short?99:101,tp2:short?96:104,tp3:short?95:105,tp4:short?94:106,tp5:short?93:107}),openedAt:now-900_000,tp1Taken:true};
    const fresh = {...analysis,bias:side,stop:short?99.5:100.5,regime:"TRENDING",structure:{...analysis.structure,bos:short?"BEARISH":"BULLISH"},metrics:{...analysis.metrics,atr:1,trendFrames:3,confirmedCandleTime:now-300_000},executionPlan:{...analysis.executionPlan,confirmationTime:now-300_000,expiresAt:now+300_000}};
    const price = short?98:102;
    assert.equal(manager.evaluateTrade(position,price,now,fresh,now).suggestedStop,fresh.stop);
    assert.equal(manager.evaluateTrade(position,price,now-30_000,fresh,now).suggestedStop,position.stop);
    const protectedPosition = {...position,stop:short?99:101};
    assert.equal(manager.evaluateTrade(protectedPosition,price,now,fresh,now).suggestedStop,protectedPosition.stop);
    assert.equal(manager.evaluateTrade(position,price,now,{...fresh,executionPlan:{...fresh.executionPlan,confirmationTime:position.openedAt-1}},now).suggestedStop,position.stop);
  }
});

function qualifiedPick(at, overrides = {}) {
  const {candles, ticker} = fixture();
  const analysis = market.analyzeMarket(candles,candles,candles,ticker);
  const raw = market.scannerRowFromAnalysis(ticker,analysis,false,undefined,"DAY");
  const row = {...raw, analyzedAt:at, flexibility:"STRICT", style:"DAY", symbol:"ETHUSDT", bias:"LONG", direction:"LONG", decision:"SETUP", entryReady:true, setupType:"BREAKOUT", setupThreshold:70, score:90, entryQuality:90, entryGrade:"A+", ratingScore:90, ratingGrade:"A+", riskBand:"LOW", regime:"TRENDING", trendFrames:3, rr:3, netRewardR:2.99, targetReliability:75, structuralTargets:3, executionCostR:.01, spreadCostLimitR:.2, turnover:500_000_000, exchangeMaxLeverage:10, quantityStep:.001, entry:100, stop:99, price:100, executionPlan:{...executionFixture(at).plan, entryLow:99.9, entryHigh:100.1, entry:100, expiresAt:at+600_000}, entryChecks:[{id:"structure",label:"Structure",required:true,status:"PASS",weight:1,detail:"Confirmed"}], btcRelationship:{...raw.btcRelationship,divergenceVerdict:"ACCEPT"},
    takeProfits:[1,2,3,4,5].map(level=>({level,price:100+level,available:true,rewardR:level,exitPct:20,confidence:"HIGH",source:"Swing liquidity",sources:["Swing liquidity"],confluenceCount:1,rationale:"Test fixture"})), ...overrides};
  return {row,rank:1,riskPct:.5,riskAmount:50,quantity:50,leverage:5,minimumLeverage:1,maximumLeverage:8,recommendedMargin:1000,marginUtilizationPct:10,leverageRationale:"Risk sized"};
}

test("First qualified scan notifies once; repeat scans and restored history do not spam", () => {
  const now = Date.now();
  const first = signals.reconcileSignals(signals.emptySignalLedger(),[qualifiedPick(now)],"DAY:STRICT",now,now);
  assert.equal(first.added.length,1);
  assert.equal(first.added[0].readAt,null);
  assert.equal(signals.reconcileSignals(first.ledger,[qualifiedPick(now)],"DAY:STRICT",now,now).added.length,0);
  const restored = signals.parseSignalLedger(JSON.stringify(first.ledger));
  const continued = signals.reconcileSignals(restored,[qualifiedPick(now+60_000)],"DAY:STRICT",now+60_000,now+60_000);
  assert.equal(continued.added.length,0);
  assert.equal(continued.ledger.notifications.length,1);
});

test("Withdrawn setups remain history and a genuinely requalified setup can alert again", () => {
  const now=Date.now();
  const first=signals.reconcileSignals(signals.emptySignalLedger(),[qualifiedPick(now)],"DAY:STRICT",now,now);
  const lost=signals.reconcileSignals(first.ledger,[],"DAY:STRICT",now+60_000,now+60_000);
  assert.equal(signals.notificationStatus(lost.ledger.notifications[0],now+60_000),"NO LONGER QUALIFIED");
  const regained=signals.reconcileSignals(lost.ledger,[qualifiedPick(now+120_000)],"DAY:STRICT",now+120_000,now+120_000);
  assert.equal(regained.added.length,1);
  assert.equal(regained.ledger.notifications.length,2);
  assert.equal(signals.notificationStatus(first.added[0],now+16*60_000),"EXPIRED SNAPSHOT");
});

test("Alert gate excludes stale, rejected, demo, wrong-mode and incomplete target signals", () => {
  const now=Date.now();
  for (const bad of [{executionPlan:undefined},{executionPlan:{...executionFixture(now).plan,status:"WAIT_RETEST"}},{executionPlan:{...executionFixture(now).plan,expiresAt:now}},{entryChecks:[{required:true,status:"WAIT"}]},{analyzedAt:now-61*60_000},{demo:true},{riskBand:"HIGH"},{flexibility:"FLEXIBLE"},{takeProfits:[]},{entryChecks:[{required:true,status:"FAIL"}]},{btcRelationship:{divergenceVerdict:"REJECT"}}]) {
    assert.equal(signals.reconcileSignals(signals.emptySignalLedger(),[qualifiedPick(now,bad)],"DAY:STRICT",now,now).added.length,0);
  }
  const initial = signals.emptySignalLedger();
  // A one-second UI clock must not consume the scan before its last rows exist.
  assert.equal(signals.reconcileSignals(initial,[qualifiedPick(now)],"DAY:STRICT",now,now-1).ledger,initial);
});

test("Signal identity distinguishes long/short and mode; copy includes all five original targets", () => {
  const now=Date.now();
  const long=qualifiedPick(now);
  const shortPlan=execution.buildEntryExecutionPlan(mirrorInput(executionFixture(now).input));
  const short=qualifiedPick(now,{bias:"SHORT",direction:"SHORT",executionPlan:shortPlan,entry:99.7,price:99.7,stop:101,takeProfits:long.row.takeProfits.map(target=>({...target,price:100-target.level}))});
  assert.notEqual(signals.signalKey(long.row),signals.signalKey(short.row));
  assert.notEqual(signals.signalKey(long.row),signals.signalKey({...long.row,flexibility:"BALANCED"}));
  const snapshot=signals.snapshotSignal(short);
  short.row.takeProfits[0].price=1;
  assert.equal(snapshot.targets[0].price,99);
  const message=signals.telegramSignalText(snapshot,true,snapshot.expiresAt);
  assert.match(message,/🔴 SHORT/);
  assert.match(message,/EXPIRED SNAPSHOT/);
  assert.equal((message.match(/🎯 TP/g)??[]).length,5);
  assert.match(message,/5×/);
  assert.match(message,/No exchange order/);
  assert.match(message,/HOW TO ENTER/);
  assert.match(message,/SELL LIMIT/);
  assert.doesNotMatch(message,/BUY LIMIT/);
  assert.match(message,/Never chase/);
  assert.match(message,/3️⃣/);
  assert.match(message,/not a fresh entry approval/);
});

test("Notification storage is bounded and corrupt records cannot crash the tab", () => {
  const snapshot=signals.snapshotSignal(qualifiedPick(Date.now()));
  const parsed=signals.parseSignalLedger(JSON.stringify({version:1,scopes:{},notifications:[null,{bad:true},...Array.from({length:120},()=>snapshot)]}));
  assert.equal(parsed.notifications.length,100);
  assert.equal(signals.parseSignalLedger("not json").notifications.length,0);
});

test("Sound schedules a bounded two-note chime only when running and unmuted", () => {
  const voices=[];
  const gains=[];
  const context={state:"running",currentTime:10,destination:{},createOscillator(){const voice={frequency:{setValueAtTime(value){voice.frequencyValue=value;}},connect(){},disconnect(){},start(time){voice.startTime=time;},stop(time){voice.stopTime=time;}};voices.push(voice);return voice;},createGain(){const gain={gain:{setValueAtTime(){},exponentialRampToValueAtTime(value){gains.push(value);}},connect(){},disconnect(){}};return gain;}};
  assert.equal(signals.playSetupChime({...context,state:"suspended"},.35),false);
  assert.equal(signals.playSetupChime(context,0),false);
  assert.equal(voices.length,0);
  assert.equal(signals.playSetupChime(context,.5),true);
  assert.equal(voices.length,2);
  assert.deepEqual(voices.map(voice=>voice.frequencyValue),[660,880]);
  assert.ok(voices.every(voice=>voice.stopTime-voice.startTime<.3));
  assert.ok(Math.max(...gains)<=.071);
});

const duration = load("app/lib/trade-duration.ts");
const tradingTime = load("app/lib/trading-time.ts");
const quotes = load("app/lib/market-quotes.ts");

test("Each mode has its own confirmation window; custom frames only shorten it", () => {
  const now = Date.parse("2026-09-20T08:00:01Z");
  for (const [style, intervalMs, expected] of [["SCALP",300_000,900_000],["DAY",900_000,3_600_000],["SWING",3_600_000,14_400_000],["POSITION",14_400_000,86_400_000]]) {
    assert.equal(duration.entryWindowMs(style, intervalMs), expected);
    const {input} = executionFixture(now);
    const end = Math.floor(now/intervalMs)*intervalMs-intervalMs;
    const candles = input.candles.map((bar,i)=>({...bar,time:end-(input.candles.length-1-i)*intervalMs}));
    const plan = execution.buildEntryExecutionPlan({...input,style,intervalMs,candles});
    assert.equal(plan.status,"READY",style);
    assert.equal(plan.expiresAt,plan.confirmationTime + intervalMs + expected);
    const rebuilt = execution.buildEntryExecutionPlan({...input,style,intervalMs,candles,now:now+10_000});
    assert.equal(rebuilt.expiresAt,plan.expiresAt,"Same candle must not restart expiry");
    assert.equal(execution.entryExecutionBlocker(plan,plan.entry,plan.expiresAt-1),null);
    assert.match(execution.entryExecutionBlocker(plan,plan.entry,plan.expiresAt),/expired/i);
    assert.equal(duration.scanEntryExpiresAt({style,analyzedAt:now,executionPlan:plan}),plan.expiresAt);
  }
  assert.equal(duration.entryWindowMs("DAY",60_000),240_000);
  assert.equal(duration.entryWindowMs("SCALP",3_600_000),900_000);
  assert.equal(duration.remainingLabel(now,now),"Expired");
});

test("Melbourne clocks and manual timestamps follow DST independently of device zone", () => {
  const winter = Date.parse("2026-07-01T00:30:00Z");
  const summer = Date.parse("2026-01-01T00:30:00Z");
  assert.equal(tradingTime.melbourneDateTimeInput(winter),"2026-07-01T10:30");
  assert.equal(tradingTime.melbourneDateTimeInput(summer),"2026-01-01T11:30");
  assert.match(tradingTime.formatMelbourneDateTime(winter),/AEST/);
  assert.match(tradingTime.formatMelbourneDateTime(summer),/AEDT/);
  assert.equal(tradingTime.parseMelbourneDateTime("2026-07-01T10:30").timestamp,winter);
  assert.equal(tradingTime.parseMelbourneDateTime("2026-10-04T02:30").timestamp,null);
  const repeated = tradingTime.parseMelbourneDateTime("2026-04-05T02:30");
  assert.equal(repeated.timestamp,null);
  assert.equal(repeated.candidates.length,2);
  assert.equal(tradingTime.parseMelbourneDateTime("2026-04-05T02:30","later").timestamp-tradingTime.parseMelbourneDateTime("2026-04-05T02:30","earlier").timestamp,3_600_000);
  assert.equal(tradingTime.parseMelbourneDateTime("2026-02-30T10:00").timestamp,null);
});

test("Daily portfolio limits reset at Melbourne midnight, not UTC midnight", () => {
  const now = Date.parse("2026-09-20T14:01:00Z"); // 00:01 Melbourne, 21 September.
  const positions = [
    {...trade(),status:"CLOSED",closedAt:Date.parse("2026-09-20T13:59:00Z"),realizedPnl:-500},
    {...trade(),status:"CLOSED",closedAt:Date.parse("2026-09-20T14:00:30Z"),realizedPnl:20},
  ];
  assert.equal(manager.getPortfolioGuard(positions,1000,"LONG",now).dailyRealizedPnl,20);
});

test("Bybit deltas preserve exact Last Price, never substitute Mark, and reject old or malformed ticks", () => {
  const now = Date.now();
  const initial = quotes.mergeMarketQuote(undefined,{lastPrice:"0.0000123400",markPrice:"0.0000123500"},now,"STREAM");
  assert.equal(initial.priceText,"0.0000123400");
  const markOnly = quotes.mergeMarketQuote(initial,{markPrice:"0.0000123600"},now+1000,"STREAM");
  assert.equal(markOnly.priceText,initial.priceText);
  assert.equal(markOnly.updatedAt,now);
  assert.equal(markOnly.markUpdatedAt,now+1000);
  assert.equal(quotes.mergeMarketQuote(markOnly,{lastPrice:"1"},now+500,"POLL"),markOnly);
  assert.equal(quotes.mergeMarketQuote(markOnly,{lastPrice:"0",markPrice:"NaN"},now+2000,"STREAM"),markOnly);
  assert.equal(quotes.mergeMarketQuote(undefined,{markPrice:"123"},now,"STREAM"),undefined);
  assert.equal(quotes.quoteIsFresh(markOnly,now+15_001),false);
  assert.equal(quotes.quoteIsFresh(initial,now-10_000),false);
});

test("Live list quotes remove pumped and stale entries from Ready without hiding the graded row", () => {
  const now = Date.now();
  const pick = qualifiedPick(now);
  const row = pick.row;
  const fresh = quotes.mergeMarketQuote(undefined,{lastPrice:"100.0000",markPrice:"100.01"},now,"STREAM");
  const high = quotes.mergeMarketQuote(fresh,{lastPrice:"101"},now+1,"STREAM");
  assert.equal(recommendations.setupStatus(row,true,now,fresh),"READY");
  assert.equal(recommendations.setupStatus(row,true,now+1,high),"RECHECK");
  assert.equal(recommendations.setupStatus(row,true,now+16_000,fresh),"RECHECK");
  assert.equal(recommendations.getMediumRiskShortlist([row],10000,true,2,now,{}).length,0);
  assert.equal(recommendations.getMediumRiskShortlist([row],10000,true,2,now,{[row.symbol]:fresh}).length,1);
  assert.equal(recommendations.getMediumRiskShortlist([row],10000,true,2,now+1,{[row.symbol]:high}).length,0);
  const waiting = {...row,entryReady:false,executionPlan:{...row.executionPlan,status:"WAIT_RETEST",confirmationTime:null},entryChecks:[]};
  const blocked = {...row,entryChecks:[{required:true,status:"FAIL"}]};
  const expired = {...row,executionPlan:{...row.executionPlan,expiresAt:now}};
  assert.deepEqual([row,waiting,blocked,expired].map(r=>recommendations.setupStatus(r,true,now,fresh)),["READY","WAITING","BLOCKED","EXPIRED"]);
  assert.equal(waiting.ratingScore,90);
  assert.equal(recommendations.setupStatus({...row,bias:"SHORT",direction:"SHORT"},true,now,quotes.mergeMarketQuote(undefined,{lastPrice:"99"},now,"STREAM")),"RECHECK");
});

test("Saved signals retain original expiry and use Melbourne time in copied instructions", () => {
  const now = Date.parse("2026-09-20T08:00:00Z");
  const snapshot = signals.snapshotSignal(qualifiedPick(now));
  const ledger = signals.reconcileSignals(signals.emptySignalLedger(),[qualifiedPick(now)],"DAY:STRICT",now,now).ledger;
  assert.equal(signals.parseSignalLedger(JSON.stringify(ledger)).notifications[0].expiresAt,snapshot.expiresAt);
  const text = signals.telegramSignalText(snapshot,false,now);
  assert.match(text,/AEST/);
  assert.match(text,/Melbourne/);
  assert.match(text,/holding/i);
  assert.equal(execution.restoreEntryExecutionPlan({...snapshot.executionPlan,style:"UNKNOWN"}),undefined);
});

const targetPolicy = load("app/lib/target-policy.ts");
test("Targets respect mode-specific reach limits for longs and shorts without a wide-stop stretch", () => {
  for (const style of ["SCALP","DAY","SWING","POSITION"]) for (const inverse of [false,true]) {
    const {candles,ticker}=fixture("ETHUSDT",inverse);
    const analysis=market.analyzeMarket(candles,candles,candles,ticker,style);
    const input={execution:candles.slice(0,-1),context:candles.slice(0,-1),macro:candles.slice(0,-1),bias:analysis.bias,entry:analysis.entry,risk:analysis.metrics.atr,atrValue:analysis.metrics.atr,ema21:analysis.entry,structure:analysis.structure,style,costAbsolute:0};
    const normal=market.buildTechnicalTargets(input),wide=market.buildTechnicalTargets({...input,risk:input.risk*20});
    assert.deepEqual(normal.levels.map(tp=>tp.price),wide.levels.map(tp=>tp.price),"Stops must not push TPs farther away");
    for(const tp of normal.levels) assert.ok(Math.abs(tp.price-input.entry)<=tp.distanceLimit+1e-9,style+" TP"+tp.level);
    assert.equal(normal.levels.reduce((sum,tp)=>sum+tp.exitPct,0),100);
    for(const tp of analysis.immediateEntry.targets) assert.ok(Math.abs(tp.price-analysis.immediateEntry.entry)<=tp.distanceLimit+1e-9);
  }
});
test("Scalps bank most size early and impulse candles cannot enlarge the distance budget",()=>{
  const candles=Array.from({length:220},(_,i)=>({time:i*300000,open:100,close:100.1,high:100.5,low:99.5,volume:1}));
  const scalp=targetPolicy.targetReach("SCALP",candles,1,"LONG",100);
  const pumped=candles.map((bar,i)=>i>216?{...bar,high:120,close:119}:bar);
  assert.equal(targetPolicy.targetReach("SCALP",pumped,10,"LONG",100).maximum,scalp.maximum);
  assert.equal(targetPolicy.TARGET_POLICY.SCALP.weights.slice(0,3).reduce((a,b)=>a+b,0),80);
  assert.ok(targetPolicy.TARGET_POLICY.SCALP.caps[4]<targetPolicy.TARGET_POLICY.DAY.caps[4]);
  assert.ok(targetPolicy.TARGET_POLICY.DAY.caps[4]<targetPolicy.TARGET_POLICY.SWING.caps[4]);
});
test("Targets inside trading costs or without inner structural evidence cannot authorize a trade",()=>{
  const {candles,ticker}=fixture();
  const analysis=market.analyzeMarket(candles,candles,candles,ticker,"SCALP",{takerFeePct:.3,slippagePct:1});
  assert.equal(analysis.entryReady,false);
  assert.equal(analysis.entryChecks.find(check=>check.id==="targets").status,"WAIT");
  assert.match(analysis.entryChecks.find(check=>check.id==="targets").detail,/round-trip/);
});
