# Mode-aware technical targets

The previous preferred target engine did not receive the trading style. It admitted levels up to max(20 ATR, 12R), used the same desired ladder for every mode, and allocated 25% to its furthest target. Risk distance could push the objectives outward. This release changes target selection and payoff checks while retaining entry confirmation, retest, no-chase, BTC, liquidity, leverage and stop-location rules.

| Mode | TP1–TP5 maximum distances in normal execution ATR | TP1–TP5 exit percentages | Minimum gross weighted R | Minimum R after estimated costs |
| --- | --- | --- | --- | --- |
| Scalp | 0.9 / 1.4 / 2 / 2.8 / 3.8 | 35 / 25 / 20 / 10 / 10 | 1.25 | 0.90 |
| Day | 1.4 / 2.3 / 3.5 / 5 / 7 | 30 / 25 / 20 / 15 / 10 | 1.60 | 1.25 |
| Swing | 2 / 3.5 / 5.5 / 8 / 11 | 25 / 25 / 20 / 15 / 15 | 2.00 | 1.60 |
| Position | 3 / 5 / 8 / 12 / 16 | 20 / 20 / 20 / 15 / 25 | 2.50 | 2.00 |

These are distance ceilings, not fixed target prices or promised reach. The engine still selects analyzed swing/liquidity, volume, VWAP, Fibonacci and candle-pattern evidence. TP1 favours the nearest qualifying obstacle. Inner TP1–TP3 require technical evidence. Outer fallback projections remain developing, capped and disclosed. Missing or uneconomic evidence blocks entry instead of manufacturing more distant levels.

Normal ATR is capped by the median true range before the last three closed candles, so a recent impulse cannot expand its own reach budget. A 70th-percentile historical favourable excursion filter over completed windows (18/48/72/84 execution bars by mode) can tighten the ceilings further. At default frames these correspond to 90 minutes / 12 hours / 3 days / 14 days. Faster custom frames shorten this historical horizon. Fewer than eight windows use the volatility cap alone. This descriptive filter is not a probability model; overlapping historical samples do not establish a target hit rate.

TP1 must clear round-trip taker fees, slippage and spread with a buffer. Preferred plans must satisfy mode-specific gross and net weighted reward floors; funding remains excluded. This replaces the previous universal 2.5R gate so realistic short-horizon exits are not forced outward just to qualify. Existing displayed after-spread metrics remain explicitly before fees/funding; the entry-proof detail separately reports the cost-adjusted gate.

Close-target/current-price alternatives share the same maximum reach limits. Wider stops do not increase target distance. Existing tracked positions retain their captured targets and exit weights; new plans use the revised policy. Existing structural-stop protection and no automatic stop widening remain in place.

Validation: 42 automated regression tests include both directions, mode caps, immediate targets, independence from stop distance, impulse resistance, fee rejection, entry safeguards, recorded targets, partial exits and journal synchronization. No win-rate or profitability improvement has been established by these software tests. Assess realized results after costs, separately by mode, before further adjustments.
