import type { Candle, TradingStyle, Bias } from "@/app/lib/market";
export const TARGET_POLICY: Record<TradingStyle,{caps:number[];weights:number[];bars:number;minimumRewardR:number;minimumNetR:number}> = {
 SCALP:{caps:[0.9,1.4,2,2.8,3.8],weights:[35,25,20,10,10],bars:18,minimumRewardR:1.25,minimumNetR:0.9},
 DAY:{caps:[1.4,2.3,3.5,5,7],weights:[30,25,20,15,10],bars:48,minimumRewardR:1.6,minimumNetR:1.25},
 SWING:{caps:[2,3.5,5.5,8,11],weights:[25,25,20,15,15],bars:72,minimumRewardR:2,minimumNetR:1.6},
 POSITION:{caps:[3,5,8,12,16],weights:[20,20,20,15,25],bars:84,minimumRewardR:2.5,minimumNetR:2},
};
/** Historical excursion is a distance filter, not a forecast or hit probability. */
export function targetReach(style:TradingStyle,candles:Candle[],atr:number,bias:Bias,entry:number) {
 const policy=TARGET_POLICY[style],sample=candles.slice(-220,-3);
 const ranges=sample.slice(-40).map((bar,i,all)=>Math.max(bar.high-bar.low,Math.abs(bar.high-(all[i-1]?.close??bar.open)),Math.abs(bar.low-(all[i-1]?.close??bar.open)))).filter(n=>n>0).sort((a,b)=>a-b);
 const normalAtr=Math.max(entry*0.00001,Math.min(atr,ranges[Math.floor(ranges.length/2)]??atr));
 const excursions:number[]=[];
 for(let start=0;start+policy.bars<=sample.length;start+=3) {
   const window=sample.slice(start,start+policy.bars),base=window[0].open;
   excursions.push(Math.max(0,bias==="LONG"?Math.max(...window.map(bar=>bar.high))-base:base-Math.min(...window.map(bar=>bar.low))));
 }
 excursions.sort((a,b)=>a-b);
 const observed=excursions.length>=8?excursions[Math.floor((excursions.length-1)*0.7)]:null;
 const maximum=Math.min(normalAtr*policy.caps[4],observed===null?Infinity:Math.max(normalAtr*0.8,observed),entry*0.8);
 return {normalAtr,maximum,caps:policy.caps.map(cap=>maximum*cap/policy.caps[4]),observed,samples:excursions.length};
}
