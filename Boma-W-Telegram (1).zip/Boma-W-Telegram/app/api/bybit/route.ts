import { NextRequest, NextResponse } from "next/server";

const API_ORIGIN = "https://api.bybit.com";
const VALID_INTERVALS = new Set([
  "1",
  "3",
  "5",
  "15",
  "30",
  "60",
  "120",
  "240",
  "360",
  "720",
  "D",
  "W",
  "M",
]);

function validSymbol(value: string) {
  return /^[A-Z0-9]{2,24}USDT$/.test(value);
}

export async function GET(request: NextRequest) {
  const search = request.nextUrl.searchParams;
  const kind = search.get("kind");
  const upstream = new URL(
    kind === "kline"
      ? "/v5/market/kline"
      : kind === "instrument" || kind === "instruments"
        ? "/v5/market/instruments-info"
        : "/v5/market/tickers",
    API_ORIGIN,
  );

  upstream.searchParams.set("category", "linear");

  if (kind === "kline") {
    const symbol = (search.get("symbol") ?? "").toUpperCase();
    const interval = search.get("interval") ?? "15";
    const limit = Math.floor(Math.min(1000, Math.max(1, Number(search.get("limit")) || 260)));

    if (!validSymbol(symbol) || !VALID_INTERVALS.has(interval)) {
      return NextResponse.json(
        { error: "Invalid symbol or interval." },
        { status: 400 },
      );
    }

    upstream.searchParams.set("symbol", symbol);
    upstream.searchParams.set("interval", interval);
    upstream.searchParams.set("limit", String(limit));
    const end = search.get("end");
    if (end !== null) {
      const timestamp = Number(end);
      if (!Number.isSafeInteger(timestamp) || timestamp <= 0 || timestamp > Date.now()) return NextResponse.json({error:"Invalid history end time."},{status:400});
      upstream.searchParams.set("end", String(timestamp));
    }
  } else if (kind === "ticker") {
    const symbol = (search.get("symbol") ?? "").toUpperCase();
    if (!validSymbol(symbol)) {
      return NextResponse.json({ error: "Invalid symbol." }, { status: 400 });
    }
    upstream.searchParams.set("symbol", symbol);
  } else if (kind === "instrument") {
    const symbol = (search.get("symbol") ?? "").toUpperCase();
    if (!validSymbol(symbol)) {
      return NextResponse.json({ error: "Invalid symbol." }, { status: 400 });
    }
    upstream.searchParams.set("symbol", symbol);
  } else if (kind === "instruments") {
    upstream.searchParams.set("limit", "1000");
    const cursor = search.get("cursor");
    if (cursor && cursor.length <= 1_000) upstream.searchParams.set("cursor", cursor);
  } else if (kind !== "tickers") {
    return NextResponse.json({ error: "Unknown market request." }, { status: 400 });
  }

  try {
    const response = await fetch(upstream, {
      cache: "no-store",
      headers: { Accept: "application/json" },
      signal: AbortSignal.timeout(8_000),
    });
    const payload = (await response.json()) as {
      retCode?: number;
      retMsg?: string;
      [key: string]: unknown;
    };

    if (!response.ok || payload?.retCode !== 0) {
      return NextResponse.json(
        { error: payload?.retMsg || "Bybit market data request failed." },
        { status: response.ok ? 502 : response.status },
      );
    }

    return NextResponse.json(payload, {
      headers: {
        "Cache-Control": "no-store, max-age=0",
        "X-Data-Source": "Bybit-V5",
      },
    });
  } catch (error) {
    return NextResponse.json(
      {
        error:
          error instanceof Error ? error.message : "Bybit market data unavailable.",
      },
      { status: 502 },
    );
  }
}
