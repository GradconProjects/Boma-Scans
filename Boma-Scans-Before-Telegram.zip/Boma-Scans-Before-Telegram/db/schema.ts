import { integer, primaryKey, sqliteTable, text } from "drizzle-orm/sqlite-core";
export const accountRecords = sqliteTable("account_records", {
  userId: text("user_id").notNull(),
  key: text("record_key").notNull(),
  payload: text("payload").notNull(),
  revision: integer("revision").notNull(),
  updatedAt: integer("updated_at").notNull(),
}, table => [primaryKey({columns:[table.userId,table.key]})]);
