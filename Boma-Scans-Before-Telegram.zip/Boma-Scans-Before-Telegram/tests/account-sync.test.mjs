import test from 'node:test';
import assert from 'node:assert/strict';
import ts from 'typescript';
import Module,{createRequire} from 'node:module';
import {readFileSync} from 'node:fs';
import {DatabaseSync} from 'node:sqlite';
const require=createRequire(import.meta.url);
const sqlite=new DatabaseSync(':memory:');
sqlite.exec(readFileSync(new URL('../drizzle/0000_stiff_leader.sql',import.meta.url),'utf8'));
let user={userId:'alice'};
const env={DB:{prepare(sql){return {bind(...args){return {async first(){return sqlite.prepare(sql).get(...args)??null;},async all(){return {results:sqlite.prepare(sql).all(...args)};}};}};}}};
const file=new URL('../app/api/sync/route.ts',import.meta.url).pathname;
const mod=new Module(file);
mod.require=spec=>{
 if(spec==='cloudflare:workers')return {env};
 if(spec==='@/app/chatgpt-auth')return {getChatGPTUser:async()=>user};
 if(spec==='@/app/lib/trade-manager')return {parseStoredTrades:value=>JSON.parse(value).filter(item=>item.id&&item.entryPrice>0)};
 return require(spec);
};
mod._compile(ts.transpileModule(readFileSync(file,'utf8'),{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2022}}).outputText,file);
const api=mod.exports;
function request(method,body,origin='https://app.local'){
 return {nextUrl:new URL('https://app.local/api/sync?scope=workspace'),headers:new Headers({origin}),text:async()=>JSON.stringify(body)};
}
const workspace={symbol:'BTCUSDT',interval:'60',style:'DAY'};
test('Account sync rejects anonymous writes and cross-origin requests',async()=>{
 user=null;assert.equal((await api.GET(request('GET'))).status,401);
 assert.equal((await api.PUT(request('PUT',{key:'workspace',value:workspace,revision:0}))).status,401);
 user={userId:'alice'};
 assert.equal((await api.PUT(request('PUT',{key:'workspace',value:workspace,revision:0},'https://other.local'))).status,403);
});
test('Two devices cannot overwrite a shared revision, and users are isolated',async()=>{
 user={userId:'alice'};
 assert.equal((await api.PUT(request('PUT',{key:'workspace',value:workspace,revision:0}))).status,200);
 const first=await (await api.GET(request('GET'))).json();
 assert.equal(first.records[0].revision,1);
 assert.equal((await api.PUT(request('PUT',{key:'workspace',value:{...workspace,symbol:'ETHUSDT'},revision:1}))).status,200);
 assert.equal((await api.PUT(request('PUT',{key:'workspace',value:{...workspace,symbol:'SOLUSDT'},revision:1}))).status,409);
 const final=await (await api.GET(request('GET'))).json();
 assert.equal(final.records[0].value.symbol,'ETHUSDT');
 user={userId:'bob'};assert.deepEqual((await (await api.GET(request('GET'))).json()).records,[]);
 assert.equal((await api.PUT(request('PUT',{key:'workspace',value:workspace,revision:0}))).status,200);
 user={userId:'alice'};assert.equal((await (await api.GET(request('GET'))).json()).records[0].value.symbol,'ETHUSDT');
});
test('Sync rejects invalid symbols, invalid revisions and malformed records',async()=>{
 user={userId:'alice'};
 for(const body of [{key:'workspace',value:{...workspace,symbol:'bad'},revision:1},{key:'workspace',value:workspace,revision:-1},{key:'other',value:workspace,revision:0}]) assert.equal((await api.PUT(request('PUT',body))).status,400);
});
