const SYMBOL_SEEDS = {
  BTCUSDT: 68250,
  ETHUSDT: 3970,
  SOLUSDT: 188,
  XRPUSDT: 2.81,
  DOGEUSDT: 0.243,
  ADAUSDT: 0.94,
  AVAXUSDT: 36.8,
  LINKUSDT: 24.2
};

const $ = (id) => document.getElementById(id);
const clamp = (v, min, max) => Math.min(max, Math.max(min, v));
const round = (v, n = 2) => Number(v).toFixed(n);
const sign = (v) => v > 0 ? '+' : '';
const now = () => Date.now();
const fmtPrice = (v) => {
  if (!Number.isFinite(v)) return '—';
  if (v >= 1000) return v.toLocaleString(undefined,{minimumFractionDigits:2, maximumFractionDigits:2});
  if (v >= 10) return v.toFixed(3);
  if (v >= 1) return v.toFixed(4);
  return v.toFixed(5);
};
const fmtUsd = (v) => `$${Number(v).toLocaleString(undefined,{minimumFractionDigits:2, maximumFractionDigits:2})}`;

const DEFAULT_SETTINGS = {
  equity: 10000,
  followTarget: 2,
  maxTrades: 4,
  sessionRiskR: 1.4,
  dailyLossR: 3,
  minScore: 72,
  maxSpreadBps: 2.2,
  cooldownSec: 5,
  makerFeeBps: 1.0,
  takerFeeBps: 2.0
};

const state = {
  settings: { ...DEFAULT_SETTINGS, ...(JSON.parse(localStorage.getItem('scalpr.settings') || '{}')) },
  market: 'linear',
  selected: 'BTCUSDT',
  side: 'long',
  dataMode: 'sim',
  feedConnected: false,
  tradingStopped: false,
  dailyR: Number(localStorage.getItem('scalpr.dailyR') || 0),
  symbols: {},
  session: null,
  position: null,
  chart: {},
  ws: null,
  currentBookSubscription: null,
  lastBook: null,
  lastFeedTs: null,
  tick: 0
};

for (const [symbol, seed] of Object.entries(SYMBOL_SEEDS)) {
  state.symbols[symbol] = createMarket(symbol, seed);
  state.chart[symbol] = Array.from({length: 160}, (_, i) => seed * (1 + Math.sin(i/11)*0.00045 + (Math.random()-.5)*0.0002));
}

function createMarket(symbol, price) {
  const direction = Math.random() > .48 ? 1 : -1;
  return {
    symbol, price, openPrice: price * (1 - direction * 0.003),
    spreadBps: 0.45 + Math.random() * 1.4,
    obi: (Math.random() - .5) * .8,
    delta3s: direction * (100000 + Math.random() * 1800000),
    microOffsetBps: direction * Math.random() * 1.2,
    volatility: .5 + Math.random(),
    trend: direction * (.2 + Math.random() * .7),
    momentum: direction * (.2 + Math.random() * .8),
    regime: direction > 0 ? 'UPTREND' : 'DOWNTREND',
    setup: 'PULLBACK',
    score: 72,
    scoreParts: {},
    scalpability: 72,
    bias: direction > 0 ? 'LONG' : 'SHORT',
    changePct: direction * .3,
    why: []
  };
}

function calcScore(m) {
  const dir = Math.sign(m.trend || 1);
  const regime = m.regime === 'CHAOTIC' ? 4 : m.regime === 'RANGE' ? 8 : m.regime === 'COMPRESSION' ? 10 : 13 + Math.abs(m.trend)*2;
  const trend = 4 + Math.abs(m.trend) * 6;
  const flowAligned = Math.sign(m.delta3s || 0) === dir;
  const orderflow = clamp(8 + (flowAligned ? 8 : -4) + Math.min(4, Math.abs(m.delta3s)/500000), 0, 20);
  const bookAligned = Math.sign(m.obi || 0) === dir;
  const book = clamp(7 + (bookAligned ? 5 : -3) + Math.abs(m.obi)*5, 0, 15);
  const momentum = clamp(5 + Math.abs(m.momentum)*5, 0, 10);
  const location = clamp(8 - Math.max(0, Math.abs(m.momentum)-.75)*12, 2, 10);
  const confirmation = clamp(4 + (flowAligned && bookAligned ? 4 : 0), 0, 8);
  const execution = clamp(12 - m.spreadBps*2.8, 0, 12);
  let penalty = 0;
  if (m.spreadBps > state.settings.maxSpreadBps) penalty += 12;
  if (m.regime === 'CHAOTIC') penalty += 22;
  if (!flowAligned && !bookAligned) penalty += 8;
  if (Math.abs(m.momentum) > .92) penalty += 5;
  const raw = regime + trend + orderflow + book + momentum + location + confirmation + execution - penalty;
  m.scoreParts = { Regime:[regime,15], Trend:[trend,10], 'Order flow':[orderflow,20], Book:[book,15], Momentum:[momentum,10], Location:[location,10], Confirmation:[confirmation,8], Execution:[execution,12] };
  m.score = Math.round(clamp(raw, 0, 100));
  m.scalpability = Math.round(clamp(m.score - m.spreadBps*2 + (m.regime === 'RANGE' ? -5 : 3),0,100));
  m.bias = m.score < 60 ? '—' : dir > 0 ? 'LONG' : 'SHORT';
  m.why = buildWhy(m, flowAligned, bookAligned);
}

function buildWhy(m, flowAligned, bookAligned) {
  const out = [];
  if (m.regime === 'UPTREND') out.push('Higher micro-structure is holding an upward regime.');
  else if (m.regime === 'DOWNTREND') out.push('Higher micro-structure is holding a downward regime.');
  else if (m.regime === 'COMPRESSION') out.push('Volatility is compressed; expansion is being monitored.');
  else out.push(`${m.regime.toLowerCase()} regime requires selective entries.`);
  out.push(flowAligned ? 'Aggressive tape flow confirms the active direction.' : 'Aggressive tape flow conflicts with the active direction.');
  out.push(bookAligned ? 'Near-book liquidity pressure confirms the move.' : 'Order-book pressure is not confirming the move.');
  out.push(m.spreadBps <= state.settings.maxSpreadBps ? 'Spread remains inside the execution gate.' : 'Spread is wider than the configured execution gate.');
  return out.slice(0,4);
}

function simulate() {
  if (state.dataMode !== 'sim') return;
  state.tick++;
  for (const m of Object.values(state.symbols)) {
    const volScale = m.price > 1000 ? 1 : m.price > 10 ? .006 : .00008;
    if (Math.random() < .018) m.trend = clamp(m.trend + (Math.random()-.5)*1.0, -1, 1);
    if (Math.random() < .012) m.regime = pickRegime(m.trend);
    const directional = m.trend * volScale * .12;
    const noise = (Math.random()-.5) * volScale * m.volatility;
    m.price = Math.max(.0001, m.price + directional + noise);
    m.changePct = ((m.price - m.openPrice) / m.openPrice) * 100;
    m.obi = clamp(m.obi*.78 + m.trend*.13 + (Math.random()-.5)*.23,-.95,.95);
    m.delta3s = m.delta3s*.63 + m.trend*(120000 + Math.random()*550000) + (Math.random()-.5)*450000;
    m.microOffsetBps = clamp(m.microOffsetBps*.7 + m.obi*.5 + (Math.random()-.5)*.35,-2,2);
    m.momentum = clamp(m.momentum*.78 + m.trend*.15 + (Math.random()-.5)*.15,-1,1);
    m.spreadBps = clamp(m.spreadBps*.85 + .15*(.45 + Math.random()*1.7) + (m.regime==='CHAOTIC'?1.2:0),.25,6);
    m.setup = chooseSetup(m);
    calcScore(m);
  }
  const selected = currentMarket();
  state.chart[state.selected].push(selected.price);
  if (state.chart[state.selected].length > 220) state.chart[state.selected].shift();
  state.lastFeedTs = now();
  updatePosition();
  updateSessionEdge();
  renderAll();
}

function pickRegime(trend) {
  const r = Math.random();
  if (r < .12) return 'COMPRESSION';
  if (r < .2) return 'RANGE';
  if (r < .24) return 'CHAOTIC';
  return trend >= 0 ? 'UPTREND' : 'DOWNTREND';
}
function chooseSetup(m) {
  if (m.regime === 'COMPRESSION') return 'MOMENTUM EXPANSION';
  if (m.regime === 'RANGE') return Math.abs(m.obi) > .5 ? 'LIQUIDITY SWEEP' : 'VWAP RECLAIM';
  if (m.regime === 'CHAOTIC') return 'NONE';
  if (Math.abs(m.momentum) > .77) return 'BREAK + RETEST';
  return 'TREND PULLBACK';
}

function currentMarket() { return state.symbols[state.selected]; }

function getCostModel() {
  const m = currentMarket();
  const mode = $('execMode').value;
  const fee = mode === 'maker' ? state.settings.makerFeeBps*2 : mode === 'taker' ? state.settings.takerFeeBps*2 : state.settings.makerFeeBps + state.settings.takerFeeBps;
  const slip = mode === 'maker' ? .15 : mode === 'taker' ? .75 : .45;
  return { fee, slip, spread: m.spreadBps, total: fee + slip + m.spreadBps };
}

function getTradePlan() {
  const m = currentMarket();
  const riskR = clamp(Number($('riskPerTrade').value || .35), .05, 1);
  const stopBps = clamp(Number($('stopBps').value || 12), 2, 100);
  const targetBps = clamp(Number($('targetBps').value || 20), 3, 200);
  const riskUsd = state.settings.equity * 0.005 * riskR; // 1R = 0.5% equity by app convention
  const stopMove = m.price * stopBps / 10000;
  const qty = riskUsd / stopMove;
  const cost = getCostModel();
  const net = targetBps - cost.total;
  const sideMul = state.side === 'long' ? 1 : -1;
  const stop = m.price * (1 - sideMul * stopBps/10000);
  const target = m.price * (1 + sideMul * targetBps/10000);
  return { riskR, stopBps, targetBps, riskUsd, qty, cost, net, stop, target, entry:m.price };
}

function gateStatus(plan) {
  const m = currentMarket();
  const session = state.session;
  const desiredBias = state.side === 'long' ? 'LONG' : 'SHORT';
  const dailyOk = state.dailyR > -state.settings.dailyLossR;
  const sessionOk = Boolean(session && session.symbol === state.selected && session.status !== 'TERMINATED');
  const cooldownOk = !sessionOk || !session.cooldownUntil || now() >= session.cooldownUntil;
  const riskRemain = !sessionOk ? 0 : state.settings.sessionRiskR - session.riskUsed;
  const gates = [
    ['Session active', sessionOk],
    ['ScalperScore', m.score >= state.settings.minScore],
    ['Spread gate', m.spreadBps <= state.settings.maxSpreadBps],
    ['Direction aligned', m.bias === desiredBias],
    ['Net edge positive', plan.net >= 4],
    ['Session risk', sessionOk && riskRemain + 1e-9 >= plan.riskR],
    ['Cooldown reset', cooldownOk],
    ['Daily loss lock', dailyOk],
    ['No open position', !state.position],
    ['Trading enabled', !state.tradingStopped]
  ];
  const pass = gates.every(g => g[1]);
  return { gates, pass };
}

function startSession() {
  if (state.position) return;
  if (state.session && state.session.status !== 'TERMINATED' && state.session.symbol !== state.selected) {
    return toast('Pair session already active', `End the ${state.session.symbol} session before following ${state.selected}.`, 'error');
  }
  const m = currentMarket();
  state.session = {
    id: `S${Date.now().toString(36).toUpperCase()}`,
    symbol: state.selected,
    market: state.market,
    initialBias: m.bias === '—' ? (state.side === 'long' ? 'LONG' : 'SHORT') : m.bias,
    currentBias: m.bias,
    primarySetup: m.setup,
    startedAt: now(),
    status: 'FOLLOWING',
    trades: [],
    riskUsed: 0,
    realizedR: 0,
    cooldownUntil: 0,
    weakTicks: 0,
    terminationReason: null
  };
  persistSession();
  toast('Pair session started', `${state.selected} is now being followed for ${state.settings.followTarget}+ qualified trade opportunities.`, 'success');
  renderAll();
}

function endSession(reason='USER_STOPPED') {
  if (!state.session) return;
  state.session.status = 'TERMINATED';
  state.session.terminationReason = reason;
  state.session.endedAt = now();
  persistSession();
  toast('Pair session ended', reason.replaceAll('_',' '), reason.includes('LOSS') ? 'error' : '');
  renderAll();
}

function updateSessionEdge() {
  const s = state.session;
  if (!s || s.status === 'TERMINATED') return;
  const m = state.symbols[s.symbol];
  if (!m) return;
  if (state.position) { s.status = 'OPEN'; return; }
  if (s.cooldownUntil && now() < s.cooldownUntil) { s.status = 'COOLDOWN'; return; }
  s.status = 'FOLLOWING';
  if (m.score < 50 || m.regime === 'CHAOTIC') s.weakTicks++; else s.weakTicks = 0;
  if (s.weakTicks >= 5) return endSession('EDGE_LOST');
  if (s.riskUsed >= state.settings.sessionRiskR - .001) return endSession('SESSION_RISK_EXHAUSTED');
  if (s.trades.length >= state.settings.maxTrades) return endSession('MAX_TRADES');
}

function placePaperTrade() {
  const plan = getTradePlan();
  const gate = gateStatus(plan);
  if (!gate.pass || !state.session) return toast('Trade rejected', gate.gates.filter(x=>!x[1]).map(x=>x[0]).join(', '), 'error');
  const tradeNo = state.session.trades.length + 1;
  state.position = {
    id:`T${Date.now().toString(36).toUpperCase()}`,
    tradeNo,
    symbol:state.selected,
    side:state.side,
    entry:plan.entry,
    stop:plan.stop,
    target:plan.target,
    qty:plan.qty,
    riskR:plan.riskR,
    riskUsd:plan.riskUsd,
    openedAt:now(),
    score:currentMarket().score,
    setup:currentMarket().setup,
    maxFav:0,
    maxAdv:0
  };
  state.session.riskUsed += plan.riskR;
  state.session.status = 'OPEN';
  toast(`Trade #${tradeNo} opened`, `${state.side.toUpperCase()} ${state.selected} at ${fmtPrice(plan.entry)} · stop ${fmtPrice(plan.stop)} · target ${fmtPrice(plan.target)}`, 'success');
  renderAll();
}

function updatePosition() {
  const p = state.position;
  if (!p) return;
  const price = state.symbols[p.symbol].price;
  const mul = p.side === 'long' ? 1 : -1;
  const pnlMove = (price - p.entry) * mul;
  const r = pnlMove / Math.abs(p.entry-p.stop) * p.riskR;
  p.maxFav = Math.max(p.maxFav, r);
  p.maxAdv = Math.min(p.maxAdv, r);
  if ((p.side === 'long' && price <= p.stop) || (p.side === 'short' && price >= p.stop)) closePaperTrade('STOP', p.stop);
  else if ((p.side === 'long' && price >= p.target) || (p.side === 'short' && price <= p.target)) closePaperTrade('TARGET', p.target);
}

function closePaperTrade(reason='MANUAL', forcedPrice=null) {
  const p = state.position;
  if (!p || !state.session) return;
  const m = state.symbols[p.symbol];
  const exit = forcedPrice ?? m.price;
  const mul = p.side === 'long' ? 1 : -1;
  const grossR = ((exit - p.entry) * mul / Math.abs(p.entry-p.stop)) * p.riskR;
  const costBps = getCostModel().total;
  const notional = p.qty * p.entry;
  const costUsd = notional * costBps / 10000;
  const netR = grossR - costUsd / (state.settings.equity * 0.005);
  const trade = {
    ...p, exit, closedAt:now(), resultR:netR, grossR, costUsd, reason,
    outcome: netR >= 0 ? 'WIN' : 'LOSS'
  };
  state.session.trades.push(trade);
  state.session.realizedR += netR;
  state.dailyR += netR;
  localStorage.setItem('scalpr.dailyR', state.dailyR);
  state.position = null;
  state.session.cooldownUntil = now() + state.settings.cooldownSec*1000;
  state.session.status = 'COOLDOWN';
  persistSession();
  toast(`Trade #${trade.tradeNo} closed ${sign(netR)}${round(netR,2)}R`, `${reason} · session ${sign(state.session.realizedR)}${round(state.session.realizedR,2)}R`, netR >= 0 ? 'success' : 'error');
  if (state.dailyR <= -state.settings.dailyLossR) {
    state.tradingStopped = true;
    endSession('DAILY_LOSS_LOCK');
  } else if (state.session.riskUsed >= state.settings.sessionRiskR - .001) endSession('SESSION_RISK_EXHAUSTED');
  else if (state.session.trades.length >= state.settings.maxTrades) endSession('MAX_TRADES');
  renderAll();
}

function persistSession() {
  if (state.session) localStorage.setItem('scalpr.lastSession', JSON.stringify(state.session));
}

function renderScanner() {
  const list = $('scannerList');
  list.innerHTML = Object.values(state.symbols).sort((a,b)=>b.scalpability-a.scalpability).map(m => {
    const sclass = m.scalpability >= 82 ? 'hot' : m.scalpability >= 65 ? 'watch' : '';
    const bclass = m.bias === 'LONG' ? 'bias-long' : m.bias === 'SHORT' ? 'bias-short' : 'bias-flat';
    return `<div class="scan-row ${m.symbol===state.selected?'active':''}" data-symbol="${m.symbol}">
      <div class="scan-pair"><strong>${m.symbol.replace('USDT','')}</strong><small>${m.regime.replace('_',' ')}</small></div>
      <div><span class="score-chip ${sclass}">${m.scalpability}</span></div>
      <div class="${bclass}">${m.bias}</div>
      <div>${round(m.spreadBps,1)} bp</div>
    </div>`;
  }).join('');
  list.querySelectorAll('.scan-row').forEach(row => row.addEventListener('click', () => selectSymbol(row.dataset.symbol)));
}

function selectSymbol(symbol) {
  if (state.position && state.position.symbol !== symbol) return toast('Position active', 'Close the open paper position before switching pairs.', 'error');
  state.selected = symbol;
  if (state.dataMode === 'live') subscribeBook(symbol);
  renderAll();
}

function renderMarket() {
  const m = currentMarket();
  $('pairTitle').textContent = state.selected;
  $('marketBadge').textContent = state.market === 'linear' ? 'PERP' : 'SPOT';
  $('lastPrice').textContent = fmtPrice(m.price);
  $('priceChange').textContent = `${sign(m.changePct)}${round(m.changePct,2)}%`;
  $('priceChange').className = m.changePct >= 0 ? 'positive' : 'negative';
  $('spreadValue').textContent = `${round(m.spreadBps,2)} bp`;
  $('obiValue').textContent = `${sign(m.obi*100)}${round(m.obi*100,0)}%`;
  $('obiValue').className = m.obi >= 0 ? 'positive' : 'negative';
  $('deltaValue').textContent = `${sign(m.delta3s/1000)}${round(m.delta3s/1000,0)}k`;
  $('deltaValue').className = m.delta3s >= 0 ? 'positive' : 'negative';
  $('microValue').textContent = `${sign(m.microOffsetBps)}${round(m.microOffsetBps,2)} bp`;
  $('regimeValue').textContent = m.regime;
  $('setupValue').textContent = m.setup;
  $('chartWatermark').textContent = `${state.selected} · ${state.dataMode==='live'?'BYBIT PUBLIC':'SIM'} · micro chart`;
  const s = state.session;
  const following = s && s.symbol === state.selected && s.status !== 'TERMINATED';
  $('sessionBadge').textContent = following ? `${s.status} · TRADE ${s.trades.length+1}` : 'NOT FOLLOWING';
  $('sessionBadge').className = following ? 'badge badge-live' : 'badge badge-muted';
  $('followBtn').classList.toggle('hidden', following);
  $('endSessionBtn').classList.toggle('hidden', !following);
}

function renderScore() {
  const m = currentMarket();
  $('scoreValue').textContent = m.score;
  const label = m.score >= state.settings.minScore ? 'QUALIFIED' : m.score >= 60 ? 'WATCH' : 'NO TRADE';
  $('signalPill').textContent = label;
  $('signalPill').className = `signal-pill ${label==='QUALIFIED'?'qualified':label==='WATCH'?'watch':''}`;
  $('scoreBreakdown').innerHTML = Object.entries(m.scoreParts).map(([name,[value,max]]) => `<div class="score-line"><span>${name}</span><div class="bar"><i style="width:${clamp(value/max*100,0,100)}%"></i></div><strong>${Math.round(value)}</strong></div>`).join('');
  $('whyList').innerHTML = m.why.map(x=>`<li>${x}</li>`).join('');
}

function renderBook() {
  const m = currentMarket();
  const rows = 7;
  const tick = m.price > 1000 ? 1 : m.price > 10 ? .01 : .0001;
  let bidTotal=0, askTotal=0;
  const bids=[], asks=[];
  if (state.dataMode==='live' && state.lastBook?.symbol===state.selected) {
    const b = state.lastBook.bids.slice(0,rows); const a = state.lastBook.asks.slice(0,rows);
    let bt=0,at=0; b.forEach(([p,q])=>{bt+=Number(q);bids.push([Number(p),Number(q),bt]);}); a.forEach(([p,q])=>{at+=Number(q);asks.push([Number(p),Number(q),at]);});
  } else {
    for(let i=0;i<rows;i++) { const q=(.3+Math.random()*2.3)*(1+m.obi*.35); bidTotal+=q; bids.push([m.price-(i+1)*tick,q,bidTotal]); const aq=(.3+Math.random()*2.3)*(1-m.obi*.35); askTotal+=aq; asks.push([m.price+(i+1)*tick,aq,askTotal]); }
  }
  const maxTotal = Math.max(...bids.map(x=>x[2]),...asks.map(x=>x[2]),1);
  const rowHtml = (r, cls) => `<div class="book-row" style="--depth:${r[2]/maxTotal*100}%"><span class="price">${fmtPrice(r[0])}</span><span>${round(r[1],3)}</span><span>${round(r[2],3)}</span></div>`;
  $('askBook').innerHTML = [...asks].reverse().map(r=>rowHtml(r,'ask')).join('');
  $('bidBook').innerHTML = bids.map(r=>rowHtml(r,'bid')).join('');
  $('bookMid').textContent = fmtPrice(m.price);
  $('bookMid').className = m.changePct >= 0 ? 'positive' : 'negative';
  $('bookSpread').textContent = `${round(m.spreadBps,2)} bp spread`;
  $('bookState').textContent = state.dataMode==='live' ? 'BYBIT L50' : 'SIMULATED L10';
}

function renderSession() {
  const s = state.session;
  $('followTargetValue').textContent = state.settings.followTarget;
  if (!s || s.symbol !== state.selected) {
    $('sessionTitle').textContent = 'No active session'; $('sessionState').textContent='IDLE'; $('sessionR').textContent='0.00R'; $('sessionRiskRemaining').textContent='—'; $('nextTrade').textContent='—'; $('cooldownValue').textContent='—';
    $('tradeDots').innerHTML = Array.from({length:state.settings.maxTrades},(_,i)=>`<i class="trade-dot ${i===0?'current':''}"></i>`).join('');
    $('sessionTrades').innerHTML='<div class="empty-state">Follow a pair to start a multi-trade session.</div>'; return;
  }
  $('sessionTitle').textContent = `${s.symbol} · ${s.initialBias}`;
  $('sessionState').textContent = s.status;
  $('sessionState').className = s.status==='TERMINATED' ? 'badge badge-muted' : 'badge badge-live';
  $('sessionR').textContent = `${sign(s.realizedR)}${round(s.realizedR,2)}R`; $('sessionR').className=s.realizedR>=0?'positive':'negative';
  $('sessionRiskRemaining').textContent = `${round(Math.max(0,state.settings.sessionRiskR-s.riskUsed),2)}R`;
  $('nextTrade').textContent = s.status==='TERMINATED' ? '—' : `#${s.trades.length+1}`;
  const cd = s.cooldownUntil && now()<s.cooldownUntil ? Math.ceil((s.cooldownUntil-now())/1000)+'s' : 'READY'; $('cooldownValue').textContent=cd;
  $('tradeDots').innerHTML = Array.from({length:state.settings.maxTrades},(_,i)=>{ const t=s.trades[i]; const cls=t?(t.outcome==='WIN'?'win':'loss'):i===s.trades.length&&s.status!=='TERMINATED'?'current':''; return `<i class="trade-dot ${cls}"></i>`; }).join('');
  $('sessionTrades').innerHTML = s.trades.length ? [...s.trades].reverse().map(t=>`<div class="session-trade"><span class="num">#${t.tradeNo}</span><span>${t.side.toUpperCase()} · ${t.setup}</span><span>${t.reason}</span><strong class="${t.resultR>=0?'positive':'negative'}">${sign(t.resultR)}${round(t.resultR,2)}R</strong></div>`).join('') : '<div class="empty-state">Session active. Waiting for the first qualified entry.</div>';
}

function renderTicket() {
  const plan = getTradePlan(); const gate=gateStatus(plan); const m=currentMarket();
  $('grossEdge').textContent=`${round(plan.targetBps,1)} bp`; $('costEdge').textContent=`${round(plan.cost.total,1)} bp`; $('netEdge').textContent=`${sign(plan.net)}${round(plan.net,1)} bp`; $('netEdge').className=plan.net>0?'positive':'negative';
  const notional=plan.qty*m.price; $('positionSizing').innerHTML=`<span>Estimated size</span><strong>${round(plan.qty, m.price<1?0:4)} ${state.selected.replace('USDT','')} · ${fmtUsd(notional)}</strong>`;
  $('riskGates').innerHTML=gate.gates.map(([name,ok])=>`<div class="gate"><span>${name}</span><strong class="${ok?'pass':'fail'}">${ok?'PASS':'BLOCK'}</strong></div>`).join('');
  const s=state.session; const active=s&&s.symbol===state.selected&&s.status!=='TERMINATED';
  if (state.position) { $('tradeBtn').classList.add('hidden'); $('closeBtn').classList.remove('hidden'); $('closeBtn').textContent=`CLOSE ${state.position.side.toUpperCase()} · ${unrealizedR().toFixed(2)}R`; }
  else { $('tradeBtn').classList.remove('hidden'); $('closeBtn').classList.add('hidden'); $('tradeBtn').disabled=!gate.pass; $('tradeBtn').textContent=!active?'START A PAIR SESSION':s.status==='COOLDOWN'?`COOLDOWN · ${Math.max(0,Math.ceil((s.cooldownUntil-now())/1000))}s`:gate.pass?`PAPER ${state.side.toUpperCase()} · TRADE #${s.trades.length+1}`:'ENTRY BLOCKED'; }
}

function unrealizedR() { const p=state.position;if(!p)return 0;const price=state.symbols[p.symbol].price;const mul=p.side==='long'?1:-1;return ((price-p.entry)*mul/Math.abs(p.entry-p.stop))*p.riskR; }

function renderAccount() {
  $('equityValue').textContent=fmtUsd(state.settings.equity + state.dailyR*state.settings.equity*.005);
  $('dailyRValue').textContent=`${sign(state.dailyR)}${round(state.dailyR,2)}R`; $('dailyRValue').className=state.dailyR>=0?'positive':'negative';
  $('openRiskValue').textContent=state.position?`${round(state.position.riskR,2)}R`:'0.00R';
  $('sessionSummary').textContent=state.session&&state.session.status!=='TERMINATED'?`${state.session.symbol} · #${state.session.trades.length+1}`:'None';
  $('riskStateLabel').textContent=state.tradingStopped?'RISK LOCKED':state.dailyR<-state.settings.dailyLossR*.6?'RISK CAUTION':'RISK NORMAL';
  $('riskStateChip').querySelector('.dot').className=`dot ${state.tradingStopped?'dot-red':state.dailyR<-state.settings.dailyLossR*.6?'dot-amber':'dot-green'}`;
  $('feedLatency').textContent=state.dataMode==='sim'?'Simulator':state.feedConnected?(state.lastFeedTs?`${Math.max(0,Date.now()-state.lastFeedTs)} ms age`:'Connected'):'Connecting…';
}

function drawChart() {
  const canvas=$('priceChart'); const rect=canvas.getBoundingClientRect(); const dpr=Math.min(devicePixelRatio||1,2); canvas.width=Math.floor(rect.width*dpr);canvas.height=Math.floor(rect.height*dpr); const ctx=canvas.getContext('2d');ctx.scale(dpr,dpr);
  const w=rect.width,h=rect.height, pad={l:12,r:68,t:14,b:18}; const arr=state.chart[state.selected]; if(!arr?.length)return;
  let min=Math.min(...arr),max=Math.max(...arr); if(state.position&&state.position.symbol===state.selected){min=Math.min(min,state.position.stop);max=Math.max(max,state.position.target);} const span=(max-min)||1; min-=span*.12;max+=span*.12;
  ctx.clearRect(0,0,w,h); ctx.strokeStyle='rgba(95,130,148,.10)';ctx.lineWidth=1; for(let i=1;i<5;i++){const y=pad.t+(h-pad.t-pad.b)*i/5;ctx.beginPath();ctx.moveTo(pad.l,y);ctx.lineTo(w-pad.r,y);ctx.stroke();}
  const xAt=i=>pad.l+i/(Math.max(1,arr.length-1))*(w-pad.l-pad.r); const yAt=p=>pad.t+(max-p)/(max-min)*(h-pad.t-pad.b);
  const grad=ctx.createLinearGradient(0,pad.t,0,h-pad.b);grad.addColorStop(0,'rgba(32,216,151,.18)');grad.addColorStop(1,'rgba(32,216,151,0)');ctx.beginPath();arr.forEach((p,i)=>{const x=xAt(i),y=yAt(p);if(i===0)ctx.moveTo(x,y);else ctx.lineTo(x,y);});ctx.lineTo(xAt(arr.length-1),h-pad.b);ctx.lineTo(xAt(0),h-pad.b);ctx.closePath();ctx.fillStyle=grad;ctx.fill();
  ctx.beginPath();arr.forEach((p,i)=>{const x=xAt(i),y=yAt(p);if(i===0)ctx.moveTo(x,y);else ctx.lineTo(x,y);});ctx.strokeStyle='#20d897';ctx.lineWidth=1.6;ctx.stroke();
  const last=arr[arr.length-1]; const ly=yAt(last);ctx.setLineDash([4,4]);ctx.strokeStyle='rgba(32,216,151,.42)';ctx.beginPath();ctx.moveTo(pad.l,ly);ctx.lineTo(w-pad.r,ly);ctx.stroke();ctx.setLineDash([]);
  const label=(p,text,color)=>{const y=yAt(p);ctx.strokeStyle=color;ctx.globalAlpha=.65;ctx.setLineDash([3,4]);ctx.beginPath();ctx.moveTo(pad.l,y);ctx.lineTo(w-pad.r,y);ctx.stroke();ctx.setLineDash([]);ctx.globalAlpha=1;ctx.fillStyle=color;ctx.font='9px ui-monospace,monospace';ctx.fillText(text,w-pad.r+7,y+3);};
  if(state.position&&state.position.symbol===state.selected){label(state.position.entry,'ENTRY','#47c6ff');label(state.position.stop,'STOP','#ff5f6d');label(state.position.target,'TARGET','#20d897');}
  ctx.fillStyle='#6f8794';ctx.font='9px ui-monospace,monospace';ctx.textAlign='left'; for(let i=0;i<4;i++){const p=min+(max-min)*(3-i)/3;ctx.fillText(fmtPrice(p),w-pad.r+7,yAt(p)+3);}ctx.textAlign='start';
}

function renderAll(){ renderScanner();renderMarket();renderScore();renderBook();renderSession();renderTicket();renderAccount();drawChart(); }

function toast(title,msg,type=''){ const el=document.createElement('div');el.className=`toast ${type}`;el.innerHTML=`<strong>${title}</strong>${msg}`;$('toastHost').appendChild(el);setTimeout(()=>el.remove(),4200); }

async function toggleDataMode() {
  if (state.dataMode==='live') { disconnectLive(); state.dataMode='sim'; $('dataModeLabel').textContent='SIM DATA'; $('dataModeBtn').querySelector('.dot').className='dot dot-amber'; toast('Simulator enabled','Using local deterministic-style market simulation.'); return renderAll(); }
  state.dataMode='live'; $('dataModeLabel').textContent='CONNECTING'; try { await connectLive(); } catch(e) { state.dataMode='sim';toast('Live public feed unavailable',`${e.message}. Simulator restored.`,'error'); }
  renderAll();
}

function connectLive() {
  return new Promise((resolve,reject)=>{
    disconnectLive();
    const category=state.market==='linear'?'linear':'spot';
    const ws=new WebSocket(`wss://stream.bybit.com/v5/public/${category}`); state.ws=ws;
    const timer=setTimeout(()=>{ try{ws.close()}catch{}; reject(new Error('Connection timed out')); },5500);
    ws.onopen=()=>{ clearTimeout(timer);state.feedConnected=true; $('dataModeLabel').textContent='BYBIT LIVE';$('dataModeBtn').querySelector('.dot').className='dot dot-green'; const args=Object.keys(state.symbols).map(s=>`tickers.${s}`); ws.send(JSON.stringify({op:'subscribe',args})); subscribeBook(state.selected);toast('Bybit public feed connected',`${category.toUpperCase()} ticker + ${state.selected} book/trades`,'success');resolve(); };
    ws.onerror=()=>{clearTimeout(timer);reject(new Error('WebSocket error'));};
    ws.onclose=()=>{state.feedConnected=false;if(state.dataMode==='live'){ $('dataModeLabel').textContent='RECONNECT';$('dataModeBtn').querySelector('.dot').className='dot dot-red';setTimeout(()=>{if(state.dataMode==='live')connectLive().catch(()=>{});},2500); }};
    ws.onmessage=(ev)=>handleLive(JSON.parse(ev.data));
  });
}

function disconnectLive(){ if(state.ws){ state.ws.onclose=null;try{state.ws.close()}catch{} }state.ws=null;state.feedConnected=false;state.lastBook=null; }
function subscribeBook(symbol){ if(!state.ws||state.ws.readyState!==1)return; if(state.currentBookSubscription){state.ws.send(JSON.stringify({op:'unsubscribe',args:[`orderbook.50.${state.currentBookSubscription}`,`publicTrade.${state.currentBookSubscription}`]}));} state.currentBookSubscription=symbol; state.ws.send(JSON.stringify({op:'subscribe',args:[`orderbook.50.${symbol}`,`publicTrade.${symbol}`]})); state.lastBook=null; }

function handleLive(msg){
  state.lastFeedTs=now(); if(!msg.topic)return; const [topic,,symbolFromBook]=msg.topic.split('.'); const symbol=topic==='orderbook'?symbolFromBook:msg.topic.split('.').slice(-1)[0]; const m=state.symbols[symbol]; if(!m)return;
  if(msg.topic.startsWith('tickers.')){ const d=msg.data; const px=Number(d.lastPrice); if(px>0){m.price=px;if(!m.openPrice)m.openPrice=Number(d.prevPrice24h)||px;m.changePct=((px-m.openPrice)/m.openPrice)*100; if(d.bid1Price&&d.ask1Price){const bid=Number(d.bid1Price),ask=Number(d.ask1Price);m.spreadBps=(ask-bid)/((ask+bid)/2)*10000;} if(symbol===state.selected){state.chart[symbol].push(px);if(state.chart[symbol].length>220)state.chart[symbol].shift();} calcScore(m);} }
  else if(msg.topic.startsWith('publicTrade.')){ const trades=Array.isArray(msg.data)?msg.data:[]; let delta=0; for(const t of trades){const usd=Number(t.p)*Number(t.v);delta += t.S==='Buy'?usd:-usd;} m.delta3s=m.delta3s*.72+delta; m.momentum=clamp(m.momentum*.8+Math.sign(delta)*.16,-1,1); calcScore(m); }
  else if(msg.topic.startsWith('orderbook.')){ const d=msg.data; if(msg.type==='snapshot'||!state.lastBook||state.lastBook.symbol!==symbol) state.lastBook={symbol,bids:d.b||[],asks:d.a||[]}; else { state.lastBook.bids=mergeBook(state.lastBook.bids,d.b||[],true);state.lastBook.asks=mergeBook(state.lastBook.asks,d.a||[],false); } if(symbol===state.selected){ const bidVol=state.lastBook.bids.slice(0,10).reduce((a,x)=>a+Number(x[1]),0), askVol=state.lastBook.asks.slice(0,10).reduce((a,x)=>a+Number(x[1]),0); m.obi=(bidVol-askVol)/(bidVol+askVol||1); if(state.lastBook.bids[0]&&state.lastBook.asks[0]){const bid=Number(state.lastBook.bids[0][0]),ask=Number(state.lastBook.asks[0][0]);m.microOffsetBps=(((ask*bidVol+bid*askVol)/(bidVol+askVol||1))-((ask+bid)/2))/((ask+bid)/2)*10000;} calcScore(m); } }
  updatePosition();updateSessionEdge();renderAll();
}
function mergeBook(existing,updates,bid){const map=new Map(existing.map(x=>[x[0],x]));for(const x of updates){if(Number(x[1])===0)map.delete(x[0]);else map.set(x[0],x);}return [...map.values()].sort((a,b)=>bid?Number(b[0])-Number(a[0]):Number(a[0])-Number(b[0])).slice(0,50);}

function openSettings(){ const s=state.settings;$('setEquity').value=s.equity;$('setFollowTarget').value=s.followTarget;$('setMaxTrades').value=s.maxTrades;$('setSessionRisk').value=s.sessionRiskR;$('setDailyLoss').value=s.dailyLossR;$('setMinScore').value=s.minScore;$('setMaxSpread').value=s.maxSpreadBps;$('setCooldown').value=s.cooldownSec;$('settingsDialog').showModal(); }
function saveSettings(){ state.settings={...state.settings,equity:Number($('setEquity').value),followTarget:clamp(Number($('setFollowTarget').value),2,8),maxTrades:clamp(Number($('setMaxTrades').value),2,12),sessionRiskR:Number($('setSessionRisk').value),dailyLossR:Number($('setDailyLoss').value),minScore:Number($('setMinScore').value),maxSpreadBps:Number($('setMaxSpread').value),cooldownSec:Number($('setCooldown').value)}; if(state.settings.maxTrades<state.settings.followTarget)state.settings.maxTrades=state.settings.followTarget;localStorage.setItem('scalpr.settings',JSON.stringify(state.settings));Object.values(state.symbols).forEach(calcScore);toast('Guardrails saved','Risk and Pair Follow thresholds updated.','success');renderAll(); }

$('settingsBtn').addEventListener('click',openSettings);$('saveSettingsBtn').addEventListener('click',saveSettings);$('dataModeBtn').addEventListener('click',toggleDataMode);$('followBtn').addEventListener('click',startSession);$('endSessionBtn').addEventListener('click',()=>endSession());
$('longBtn').addEventListener('click',()=>{state.side='long';$('longBtn').classList.add('active');$('shortBtn').classList.remove('active');renderTicket();});$('shortBtn').addEventListener('click',()=>{state.side='short';$('shortBtn').classList.add('active');$('longBtn').classList.remove('active');renderTicket();});
['riskPerTrade','stopBps','targetBps','execMode'].forEach(id=>$(id).addEventListener('input',renderTicket));
$('tradeBtn').addEventListener('click',()=>{if(!state.session||state.session.symbol!==state.selected||state.session.status==='TERMINATED'){startSession();return;}placePaperTrade();});$('closeBtn').addEventListener('click',()=>closePaperTrade('MANUAL'));
$('killBtn').addEventListener('click',()=>$('killDialog').showModal());$('confirmKillBtn').addEventListener('click',()=>{if(state.position)closePaperTrade('KILL_SWITCH');state.tradingStopped=true;if(state.session&&state.session.status!=='TERMINATED')endSession('KILL_SWITCH');toast('Trading stopped','New entries are locked until the page is reloaded and the kill state is reset in code/configuration.','error');renderAll();});
$('marketSegment').querySelectorAll('button').forEach(btn=>btn.addEventListener('click',()=>{ if(state.position)return toast('Position active','Close the position before changing market category.','error'); $('marketSegment').querySelectorAll('button').forEach(b=>b.classList.remove('active'));btn.classList.add('active');state.market=btn.dataset.market;if(state.dataMode==='live')connectLive().catch(()=>{});renderAll(); }));
window.addEventListener('resize',drawChart);

for(const m of Object.values(state.symbols)) calcScore(m);
renderAll();
setInterval(simulate,650);
setInterval(()=>{ if(state.session?.status==='COOLDOWN'&&now()>=state.session.cooldownUntil){state.session.status='FOLLOWING';renderAll();} else renderTicket(); renderAccount(); },500);

fetch('/api/config').then(r=>r.json()).then(cfg=>{ if(cfg.bybitConfigured) toast('Bybit server adapter ready', cfg.liveTradingEnabled?'Live execution is enabled server-side.':'Private credentials detected; live execution remains locked.'); }).catch(()=>{});
