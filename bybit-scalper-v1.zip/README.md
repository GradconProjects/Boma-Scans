# SCALPR — Bybit Spot + Perps V1

A dependency-free web app prototype for Bybit-native spot and USDT perpetual scalping. It includes a market scanner, deterministic ScalperScore, order-book/tape features, Pair Follow sessions for 2+ qualified trades, session risk budgets, cooldowns, a kill switch, paper execution, and optional Bybit public WebSocket data.

## Run

Requires Node.js 20+.

```bash
cd bybit-scalper
node server.mjs
```

Open `http://localhost:3000`.

No `npm install` is required.

## What works now

- Paper trading with automatic stop/target handling.
- Pair Follow sessions; after each exit the pair returns to cooldown and must re-qualify for the next trade.
- No martingale or automatic loss-based size increase.
- Session risk budget, daily loss lock, minimum score, maximum spread, and cooldown guardrails.
- Multi-pair scalpability scanner.
- Explainable score breakdown.
- Simulated order book and tape.
- Optional Bybit public WebSocket toggle for live tickers, public trades, and L50 order book.
- Server-side Bybit signing endpoints for fee rate, positions, order creation, and cancel-all.
- Live order creation is locked by default.

## Bybit private API setup

Copy `.env.example` values into your shell or deployment environment. Never put the API secret in browser code.

```bash
export BYBIT_BASE_URL=https://api.bybit.com
export BYBIT_API_KEY=...
export BYBIT_API_SECRET=...
```

The server will expose read-only signed endpoints when credentials exist, but order creation remains locked.

To deliberately enable live order creation you must set **both**:

```bash
export ENABLE_LIVE_TRADING=true
export LIVE_TRADING_CONFIRM=I_UNDERSTAND
```

Live execution is intentionally not wired to the UI in this V1 because exchange-native protection verification and private WebSocket reconciliation should be implemented before one-click real-money execution is exposed.

## Paper-risk convention

For position sizing, the prototype defines `1R = 0.5% of configured paper equity`. A ticket risk of `0.35R` therefore uses 0.175% of equity as the maximum stop-loss risk before estimated costs.

This is a configurable engineering convention, not a claim that it is an optimal risk level.

## Production hardening still required before real money

- Private WebSocket order/execution/position reconciliation.
- Exchange-native stop/TP attachment and verification.
- Instrument tick/quantity normalization from `/v5/market/instruments-info`.
- Account-specific maker/taker fee refresh in the live cost model.
- Persistent database and audit log.
- Authentication and encrypted secret storage.
- Rate limiting, CSRF protection, structured monitoring, and deployment secret management.
- Full demo/testnet soak testing and replay/backtesting.

## Files

- `server.mjs` — static server + minimal signed Bybit REST adapter.
- `public/index.html` — trading terminal shell.
- `public/styles.css` — responsive terminal UI.
- `public/app.js` — market simulation/live public feed, scoring, Pair Follow state machine, risk engine, and paper execution.
