import http from 'node:http';
import { readFile, stat } from 'node:fs/promises';
import { extname, join, normalize } from 'node:path';
import crypto from 'node:crypto';

const PORT = Number(process.env.PORT || 3000);
const ROOT = join(process.cwd(), 'public');
const BASE_URL = process.env.BYBIT_BASE_URL || 'https://api.bybit.com';
const API_KEY = process.env.BYBIT_API_KEY || '';
const API_SECRET = process.env.BYBIT_API_SECRET || '';
const LIVE_ENABLED = process.env.ENABLE_LIVE_TRADING === 'true' && process.env.LIVE_TRADING_CONFIRM === 'I_UNDERSTAND';
const RECV_WINDOW = '5000';

const mime = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.ico': 'image/x-icon'
};

function json(res, status, data) {
  res.writeHead(status, { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store' });
  res.end(JSON.stringify(data));
}

async function bodyJson(req) {
  let raw = '';
  for await (const chunk of req) raw += chunk;
  if (!raw) return {};
  try { return JSON.parse(raw); } catch { throw new Error('Invalid JSON body'); }
}

function sign(payload, timestamp) {
  const raw = `${timestamp}${API_KEY}${RECV_WINDOW}${payload}`;
  return crypto.createHmac('sha256', API_SECRET).update(raw).digest('hex');
}

async function bybitRequest(method, path, { query = '', body = null, auth = false } = {}) {
  const ts = Date.now().toString();
  const payload = method === 'GET' ? query : JSON.stringify(body ?? {});
  const headers = { 'content-type': 'application/json' };
  if (auth) {
    if (!API_KEY || !API_SECRET) throw new Error('Bybit API credentials are not configured');
    headers['X-BAPI-API-KEY'] = API_KEY;
    headers['X-BAPI-TIMESTAMP'] = ts;
    headers['X-BAPI-RECV-WINDOW'] = RECV_WINDOW;
    headers['X-BAPI-SIGN'] = sign(payload, ts);
  }
  const url = `${BASE_URL}${path}${method === 'GET' && query ? `?${query}` : ''}`;
  const r = await fetch(url, { method, headers, body: method === 'GET' ? undefined : payload });
  const data = await r.json().catch(() => ({ retCode: -1, retMsg: `HTTP ${r.status}` }));
  return { status: r.status, data };
}

function validateOrder(input) {
  const allowedCategories = new Set(['linear', 'spot']);
  const allowedSides = new Set(['Buy', 'Sell']);
  const allowedTypes = new Set(['Market', 'Limit']);
  if (!allowedCategories.has(input.category)) throw new Error('Unsupported category');
  if (!/^[A-Z0-9]{3,20}$/.test(input.symbol || '')) throw new Error('Invalid symbol');
  if (!allowedSides.has(input.side)) throw new Error('Invalid side');
  if (!allowedTypes.has(input.orderType)) throw new Error('Invalid order type');
  if (!(Number(input.qty) > 0)) throw new Error('Quantity must be positive');
  if (input.orderType === 'Limit' && !(Number(input.price) > 0)) throw new Error('Limit price required');
  return {
    category: input.category,
    symbol: input.symbol,
    side: input.side,
    orderType: input.orderType,
    qty: String(input.qty),
    ...(input.price ? { price: String(input.price) } : {}),
    timeInForce: input.timeInForce || (input.orderType === 'Limit' ? 'PostOnly' : 'IOC'),
    positionIdx: Number(input.positionIdx || 0),
    reduceOnly: Boolean(input.reduceOnly),
    orderLinkId: String(input.orderLinkId || `sc_${Date.now()}`).slice(0, 36),
    ...(input.slippageToleranceType ? { slippageToleranceType: input.slippageToleranceType } : {}),
    ...(input.slippageTolerance ? { slippageTolerance: String(input.slippageTolerance) } : {})
  };
}

async function handleApi(req, res, url) {
  if (url.pathname === '/api/config' && req.method === 'GET') {
    return json(res, 200, {
      paperMode: true,
      bybitConfigured: Boolean(API_KEY && API_SECRET),
      liveTradingEnabled: LIVE_ENABLED,
      bybitBaseUrl: BASE_URL,
      warning: 'Live execution is intentionally locked unless ENABLE_LIVE_TRADING=true and LIVE_TRADING_CONFIRM=I_UNDERSTAND.'
    });
  }

  if (url.pathname === '/api/bybit/time' && req.method === 'GET') {
    try {
      const out = await bybitRequest('GET', '/v5/market/time');
      return json(res, out.status, out.data);
    } catch (e) { return json(res, 502, { error: e.message }); }
  }

  if (url.pathname === '/api/bybit/fee-rate' && req.method === 'GET') {
    try {
      const params = new URLSearchParams({
        category: url.searchParams.get('category') || 'linear',
        symbol: url.searchParams.get('symbol') || 'BTCUSDT'
      });
      const out = await bybitRequest('GET', '/v5/account/fee-rate', { query: params.toString(), auth: true });
      return json(res, out.status, out.data);
    } catch (e) { return json(res, 502, { error: e.message }); }
  }

  if (url.pathname === '/api/bybit/positions' && req.method === 'GET') {
    try {
      const params = new URLSearchParams({ category: url.searchParams.get('category') || 'linear', settleCoin: 'USDT' });
      const out = await bybitRequest('GET', '/v5/position/list', { query: params.toString(), auth: true });
      return json(res, out.status, out.data);
    } catch (e) { return json(res, 502, { error: e.message }); }
  }

  if (url.pathname === '/api/bybit/order' && req.method === 'POST') {
    if (!LIVE_ENABLED) return json(res, 423, { error: 'Live trading is locked on this server.' });
    try {
      const input = await bodyJson(req);
      const order = validateOrder(input);
      const out = await bybitRequest('POST', '/v5/order/create', { body: order, auth: true });
      return json(res, out.status, out.data);
    } catch (e) { return json(res, 400, { error: e.message }); }
  }

  if (url.pathname === '/api/bybit/cancel-all' && req.method === 'POST') {
    if (!LIVE_ENABLED) return json(res, 423, { error: 'Live trading is locked on this server.' });
    try {
      const input = await bodyJson(req);
      const body = {
        category: input.category || 'linear',
        ...(input.symbol ? { symbol: input.symbol } : {}),
        ...(input.settleCoin ? { settleCoin: input.settleCoin } : { settleCoin: 'USDT' })
      };
      const out = await bybitRequest('POST', '/v5/order/cancel-all', { body, auth: true });
      return json(res, out.status, out.data);
    } catch (e) { return json(res, 400, { error: e.message }); }
  }

  return json(res, 404, { error: 'API route not found' });
}

async function serveStatic(req, res, url) {
  let path = decodeURIComponent(url.pathname);
  if (path === '/') path = '/index.html';
  const safe = normalize(path).replace(/^([.][.][/\\])+/, '');
  const file = join(ROOT, safe);
  if (!file.startsWith(ROOT)) return json(res, 403, { error: 'Forbidden' });
  try {
    const s = await stat(file);
    if (!s.isFile()) throw new Error('Not a file');
    const data = await readFile(file);
    res.writeHead(200, {
      'content-type': mime[extname(file)] || 'application/octet-stream',
      'cache-control': extname(file) === '.html' ? 'no-store' : 'public, max-age=3600'
    });
    res.end(data);
  } catch {
    const fallback = await readFile(join(ROOT, 'index.html'));
    res.writeHead(200, { 'content-type': 'text/html; charset=utf-8', 'cache-control': 'no-store' });
    res.end(fallback);
  }
}

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
  try {
    if (url.pathname.startsWith('/api/')) return await handleApi(req, res, url);
    return await serveStatic(req, res, url);
  } catch (e) {
    return json(res, 500, { error: e.message || 'Internal server error' });
  }
});

server.listen(PORT, () => {
  console.log(`Bybit Scalper running at http://localhost:${PORT}`);
  console.log(`Execution: ${LIVE_ENABLED ? 'LIVE ENABLED' : 'PAPER / LIVE LOCKED'}`);
});
