export default function Versions() {
 const versions=[
  {name:"Boma W Telegram",url:"https://boma-scans-version-15.bomsilaga.chatgpt.site",label:"Latest version",items:["Telegram alerts and interactive commands","Timeframe and manual pair analysis in Telegram","Revised nearer targets with 40% / 35% profit-taking at TP1 / TP2","Liquidity-sweep, reclaim and later confirmation for pullbacks"]},
  {name:"Boma Scans — Before Telegram",url:"https://boma-before-telegram.bomsilaga.chatgpt.site",label:"Saved pre-Telegram version",items:["Original website workflow before bot integration","Historical target and entry rules preserved","1-hour default chart, candle-history paging and device sync","Independent settings and journal"]}
 ];
 return <main className="mx-auto max-w-6xl px-5 py-10 text-slate-200">
  <h1 className="text-3xl font-bold">Choose your Boma version</h1>
  <p className="mt-3 text-base leading-7 text-slate-400">Open either version below. Each has its own saved settings and trade journal. You can switch using the buttons at the top of either app.</p>
  <div className="mt-8 grid gap-5 md:grid-cols-2">{versions.map(version=><section key={version.name} className="rounded-2xl border border-white/15 bg-[#0b1520] p-6">
   <p className="text-sm font-semibold text-cyan-300">{version.label}</p>
   <h2 className="mt-2 text-2xl font-bold">{version.name}</h2>
   <ul className="my-6 list-disc space-y-3 pl-5 text-base leading-6">{version.items.map(item=><li key={item}>{item}</li>)}</ul>
   <a href={version.url} className="inline-block rounded-xl bg-cyan-300 px-4 py-3 font-bold text-slate-950">Open this version</a>
   <a href={version.url} target="_blank" rel="noopener noreferrer" className="ml-4 inline-block py-3 text-sm text-cyan-200 underline">Open in another tab</a>
  </section>)}</div>
 </main>;
}
