import { env } from "cloudflare:workers";
import { journalLoginUrl, journalOwner } from "@/app/server/journal-auth";
import { validTrade } from "@/app/lib/journal-sync";
const reply = (body: unknown,status=200) => Response.json(body,{status,headers:{"Cache-Control":"private, no-store","Vary":"Cookie"}});
function database() {if (!env.DB) throw new Error("Journal unavailable");return env.DB;}
type Stored = {data: string; revision: number};
const record = (row: Stored) => ({trade:JSON.parse(row.data),revision:row.revision});
export async function GET(request: Request) {
  const owner=await journalOwner(request);
  if (!owner) return reply({error:"Sign in to sync your journal.",loginUrl:journalLoginUrl},401);
  try {
    const result=await database().prepare("SELECT data, revision FROM trade_journal WHERE owner = ? ORDER BY updated_at DESC").bind(owner).all<Stored>();
    return reply({owner,records:result.results.map(record)});
  } catch {return reply({error:"Cloud journal is temporarily unavailable. Device changes are kept for retry."},503);}
}
export async function PUT(request: Request) {
  const owner=await journalOwner(request);
  if (!owner) return reply({error:"Sign in to sync your journal.",loginUrl:journalLoginUrl},401);
  const origin=request.headers.get("origin");
  if (origin!==new URL(request.url).origin) return reply({error:"Invalid request origin."},403);
  if (!request.headers.get("content-type")?.startsWith("application/json")) return reply({error:"JSON required."},415);
  try {
    const raw=await request.text();if (raw.length>65_536) return reply({error:"Trade record is too large."},413);
    const body=JSON.parse(raw);
    if (body.owner!==owner) return reply({error:"Account changed. Reload before syncing this journal."},409);
    if (!Number.isInteger(body.base) || body.base<0 || !validTrade(body.trade)) return reply({error:"Invalid trade record."},400);
    const data=JSON.stringify(body.trade),db=database(),id=body.trade.id;
    // Compare-and-swap prevents a second device replacing newer fills or closures.
    const saved=body.base===0
      ? await db.prepare("INSERT INTO trade_journal(owner,id,revision,data,updated_at) VALUES(?,?,1,?,?) ON CONFLICT(owner,id) DO NOTHING RETURNING data,revision").bind(owner,id,data,Date.now()).first<Stored>()
      : await db.prepare("UPDATE trade_journal SET data=?,revision=revision+1,updated_at=? WHERE owner=? AND id=? AND revision=? RETURNING data,revision").bind(data,Date.now(),owner,id,body.base).first<Stored>();
    if (saved) return reply({record:record(saved)});
    const current=await db.prepare("SELECT data,revision FROM trade_journal WHERE owner=? AND id=?").bind(owner,id).first<Stored>();
    if (current?.data===data) return reply({record:record(current)}); // Lost acknowledgement: idempotent retry.
    return reply({error:"This trade changed on another device.",record:current?record(current):null},409);
  } catch (error) {return reply({error:error instanceof SyntaxError?"Invalid JSON.":"Cloud save failed. Keep this tab until your pending changes sync."},error instanceof SyntaxError?400:503);}
}
