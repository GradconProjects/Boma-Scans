import { env } from "cloudflare:workers";
import { validOwnerSession } from "@/app/lib/owner-session";
export const journalLoginUrl="/login";
export async function journalOwner(request:Request) {
  const secret=env.BOMA_SYNC_SECRET;
  if(!secret || secret.length<32) return null;
  const token=request.headers.get("cookie")?.split(";").map(part=>part.trim()).find(part=>part.startsWith("__Host-boma-session="))?.slice("__Host-boma-session=".length)??"";
  return await validOwnerSession(token,secret) ? "private-owner" : null;
}
