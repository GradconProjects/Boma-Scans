import { formatPrice } from "@/app/lib/market";
import { quoteIsFresh, type LiveMarketQuote } from "@/app/lib/market-quotes";
import { formatMelbourneClock } from "@/app/lib/trading-time";

export function QuotePrice({quote, now, scanPrice, scanAt, details = false}: {
  quote?: LiveMarketQuote; now: number; scanPrice: number; scanAt: number; details?: boolean;
}) {
  const fresh = quoteIsFresh(quote, now);
  return <span className="block" title={(fresh ? "Bybit Last Price · " : "Last observed price · ") + formatMelbourneClock(quote?.updatedAt ?? scanAt)}>
    <span className={"block break-all font-mono text-sm " + (fresh ? "text-slate-200" : "text-amber-200/70")}>{quote?.priceText ?? formatPrice(scanPrice)}</span>
    <span className={"mt-0.5 block text-xs " + (fresh ? "text-emerald-300/75" : "text-amber-200/70")}>{fresh ? quote?.source === "STREAM" ? "Bybit Last · live" : "Bybit Last · 5s refresh" : quote ? "STALE · refresh needed" : "Scan price · awaiting live"}</span>
    {details && <span className="mt-1 block text-xs text-slate-500">Mark {quote?.markText ?? "—"}{quote && now - quote.markUpdatedAt > 15_000 ? " (stale)" : ""} · checked {formatMelbourneClock(quote?.updatedAt ?? scanAt)}</span>}
  </span>;
}
