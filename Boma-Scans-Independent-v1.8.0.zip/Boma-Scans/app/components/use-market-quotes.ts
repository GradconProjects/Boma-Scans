"use client";
import { useEffect, useRef, useState } from "react";
import { fetchTickers } from "@/app/lib/market";
import { mergeMarketQuote, type LiveMarketQuote } from "@/app/lib/market-quotes";

/** All list prices use Bybit quotes independently of the slower TA scan. */
export function useMarketQuotes(symbols: string[]) {
  const [quotes, setQuotes] = useState<Record<string, LiveMarketQuote>>({});
  const saved = useRef<Record<string, LiveMarketQuote>>({});
  const key = [...new Set(symbols)].sort().join(",");
  useEffect(() => {
    if (!key) return;
    const watched = new Set(key.split(","));
    const cache = {...saved.current};
    let dirty = false, stopped = false, polling = false, attempts = 0;
    let socket: WebSocket | null = null;
    let reconnect: number | undefined;
    const subscriptions: number[] = [];
    const controller = new AbortController();
    const update = (symbol: string, raw: Record<string, unknown>, at: number, source: "STREAM" | "POLL") => {
      if (!watched.has(symbol)) return;
      const next = mergeMarketQuote(cache[symbol], raw, at, source);
      if (next && next !== cache[symbol]) {cache[symbol] = next; dirty = true;}
    };
    async function poll() {
      if (polling || stopped) return;
      polling = true;
      try {
        const tickers = await fetchTickers(controller.signal);
        if (stopped) return;
        for (const ticker of tickers) update(ticker.symbol, {...ticker}, ticker.observedAt ?? Date.now(), "POLL");
      } catch { /* Existing values age into STALE; never replace them with synthetic quotes. */ }
      finally {polling = false;}
    }
    function connect() {
      if (stopped) return;
      socket = new WebSocket("wss://stream.bybit.com/v5/public/linear");
      const snapshots = new Set<string>();
      socket.onopen = () => {
        attempts = 0;
        const topics = [...watched].map(symbol => "tickers." + symbol);
        for (let index = 0; index < topics.length; index += 20) {
          subscriptions.push(window.setTimeout(() => {
            if (socket?.readyState === WebSocket.OPEN) socket.send(JSON.stringify({op:"subscribe",args:topics.slice(index,index+20)}));
          }, index / 20 * 150));
        }
      };
      socket.onmessage = event => {
        try {
          const message = JSON.parse(event.data);
          if (!message.topic?.startsWith("tickers.")) return;
          const symbol = message.topic.slice(8);
          if (message.type === "snapshot") snapshots.add(symbol);
          if (!snapshots.has(symbol)) return;
          const raw = Array.isArray(message.data) ? message.data[0] : message.data;
          if (raw && Number.isFinite(message.ts)) update(symbol,raw,message.ts,"STREAM");
        } catch { /* Invalid messages never refresh a quote timestamp. */ }
      };
      socket.onerror = () => socket?.close();
      socket.onclose = () => {
        for (const timer of subscriptions.splice(0)) window.clearTimeout(timer);
        if (!stopped) reconnect = window.setTimeout(connect, Math.min(15_000, 1000 * 2 ** attempts++));
      };
    }
    connect();
    void poll();
    const pollTimer = window.setInterval(() => void poll(), 5000);
    const heartbeat = window.setInterval(() => {if (socket?.readyState === WebSocket.OPEN) socket.send(JSON.stringify({op:"ping"}));},20_000);
    // Batch display updates, without interpolating or altering exchange prices.
    const flush = window.setInterval(() => {
      if (!dirty) return;
      dirty = false; saved.current = {...cache}; setQuotes(saved.current);
    }, 250);
    const refresh = () => {if (document.visibilityState === "visible") void poll();};
    document.addEventListener("visibilitychange",refresh);
    return () => {
      stopped = true; controller.abort(); socket?.close();
      window.clearTimeout(reconnect);
      subscriptions.forEach(timer => window.clearTimeout(timer));
      [pollTimer, heartbeat, flush].forEach(timer => window.clearInterval(timer));
      document.removeEventListener("visibilitychange",refresh);
    };
  },[key]);
  return quotes;
}
