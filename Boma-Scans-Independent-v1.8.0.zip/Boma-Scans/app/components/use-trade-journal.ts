"use client";
import { useCallback, useEffect, useRef, useState, type SetStateAction } from "react";
import { parseStoredTrades, TRADE_STORAGE_KEY, type TrackedTrade } from "@/app/lib/trade-manager";
import { validTrade, acknowledgeTrade, emptyJournal, journalTrades, mergeJournal, queueTrades, resolveJournalConflict, restoreJournal, type JournalRecord, type JournalState } from "@/app/lib/journal-sync";
const readLocal=(key:string)=>{try{return localStorage.getItem(key);}catch{return null;}};
const cacheKey = (owner: string) => "boma-scans:journal:v1:" + owner;
export function useTradeJournal() {
  const current = useRef<JournalState>(emptyJournal(""));
  const [state,setState] = useState<JournalState>(()=>emptyJournal(""));
  const [ready,setReady] = useState(false);
  const [status,setStatus] = useState("Connecting to your cloud journal…");
  const [loginUrl,setLoginUrl] = useState("");
  const [storageError,setStorageError] = useState("");
  const busy = useRef(false), stopped = useRef(false);
  const persist = useCallback((next: JournalState) => {
    current.current=next;setState(next);
    try {
      if (next.owner) {localStorage.setItem(cacheKey(next.owner),JSON.stringify(next));localStorage.setItem("boma-scans:journal:last-owner",next.owner);}
      else localStorage.setItem(TRADE_STORAGE_KEY,JSON.stringify(journalTrades(next)));
      setStorageError("");
    } catch {setStorageError("This browser cannot save an offline backup. Keep it open until cloud sync finishes.");}
  },[]);
  const sync = useCallback(async () => {
    if (busy.current || stopped.current) return;
    busy.current=true;
    try {
      const response=await fetch("/api/journal",{cache:"no-store",credentials:"same-origin",signal:AbortSignal.timeout(15_000)});
      if (!response.headers.get("content-type")?.includes("application/json")) throw new Error("Sign-in expired. Reopen Boma Scans to reconnect.");
      const body=await response.json() as {owner:string;records:JournalRecord[];error?:string;loginUrl?:string};
      if (!response.ok) {if (response.status===401) setLoginUrl(body.loginUrl || "/login");throw new Error(body.error||"Cloud journal unavailable.");}
      if (stopped.current) return;
      if (typeof body.owner!=="string" || !Array.isArray(body.records)) throw new Error("Cloud journal returned an invalid response.");
      setLoginUrl("");
      if (current.current.owner!==body.owner) {
        let restored=restoreJournal(readLocal(cacheKey(body.owner)),body.owner);
        const legacyOwner=readLocal("boma-scans:journal:legacy-owner");
        if (!legacyOwner) {
          const legacy=parseStoredTrades(readLocal(TRADE_STORAGE_KEY));
          // Import IDs not already represented in this account's cloud/local journal.
          const existing=new Set([...Object.keys(restored.records),...Object.keys(restored.pending)]);
          restored=queueTrades(restored,legacy.filter(trade=>!existing.has(trade.id)));
          try {localStorage.setItem("boma-scans:journal:legacy-owner",body.owner);} catch {setStorageError("Offline backup is unavailable in this browser.");}
        }
        persist(restored);
      }
      persist(mergeJournal(current.current,body.records));
      setReady(true);
      for (const [id,sent] of Object.entries(current.current.pending)) {
        if (current.current.conflicts[id] || stopped.current) continue;
        const owner=current.current.owner;
        const result=await fetch("/api/journal",{method:"PUT",credentials:"same-origin",headers:{"Content-Type":"application/json"},body:JSON.stringify({...sent,owner}),signal:AbortSignal.timeout(15_000)});
        const saved=await result.json() as {record:JournalRecord;error?:string};
        if (stopped.current || current.current.owner!==owner) return;
        if (result.status===409 && saved.record) {persist(mergeJournal(current.current,[saved.record]));continue;}
        if (!result.ok) throw new Error(saved.error||"Cloud save failed.");
        persist(acknowledgeTrade(current.current,sent,saved.record));
      }
      const conflicts=Object.keys(current.current.conflicts).length,pending=Object.keys(current.current.pending).length;
      setStatus(conflicts ? "Review conflicting changes below" : pending ? `${pending} changes waiting to sync` : "Cloud synced · same account on every device");
    } catch (error) {
      if (stopped.current) return;
      setStatus((error instanceof Error ? error.message : "Offline") + " Changes stay on this device until synced.");
      if (!current.current.owner && !Object.keys(current.current.pending).length) {
        try {
          const owner=readLocal("boma-scans:journal:last-owner");
          persist(owner ? restoreJournal(readLocal(cacheKey(owner)),owner) : queueTrades(emptyJournal(""),parseStoredTrades(readLocal(TRADE_STORAGE_KEY))));
        } catch {setStorageError("Device backup is unavailable.");}
      }
      setReady(true);
    } finally {busy.current=false;}
  },[persist]);
  useEffect(() => {
    stopped.current=false;
    const start=window.setTimeout(()=>void sync(),0);
    const timer=window.setInterval(()=>{if (document.visibilityState==="visible") void sync();},10_000);
    const resume=()=>{if (document.visibilityState==="visible") void sync();};
    window.addEventListener("online",resume);document.addEventListener("visibilitychange",resume);
    return ()=>{stopped.current=true;window.clearTimeout(start);window.clearInterval(timer);window.removeEventListener("online",resume);document.removeEventListener("visibilitychange",resume);};
  },[sync]);
  const setTrades = useCallback((update: SetStateAction<TrackedTrade[]>) => {
    const previous=journalTrades(current.current);
    persist(queueTrades(current.current,typeof update==="function"?update(previous):update));
    setStatus("Saving changes…");void sync();
  },[persist,sync]);
  function resolve(id: string,keepLocal: boolean) {persist(resolveJournalConflict(current.current,id,keepLocal));void sync();}
  function exportBackup() {
    const blob=new Blob([JSON.stringify(journalTrades(current.current),null,2)],{type:"application/json"});
    const url=URL.createObjectURL(blob),link=document.createElement("a");link.href=url;link.download="boma-scans-trades.json";link.click();window.setTimeout(()=>URL.revokeObjectURL(url),1000);
  }
  async function importBackup(file:File) {
    try {
      if(file.size>4_000_000) throw new Error("Backup is too large (maximum 4 MB).");
      const raw=await file.text(),parsed=JSON.parse(raw);
      const imported=parseStoredTrades(raw);
      if(!Array.isArray(parsed) || imported.length!==parsed.length || !imported.every(validTrade)) throw new Error("This is not a valid Boma Scans trade backup.");
      const ids=new Set(journalTrades(current.current).map(trade=>trade.id));
      const added=imported.filter(trade=>!ids.has(trade.id));
      if(!added.length) {setStatus("No new trades to import; existing records were preserved.");return;}
      persist(queueTrades(current.current,added));setStatus(`Imported ${added.length} trades. Syncing…`);void sync();
    }catch(error){setStatus(error instanceof Error?error.message:"Import failed.");}
  }
  return {trades:journalTrades(state),setTrades,ready,status,loginUrl,storageError,conflicts:state.conflicts,pending:state.pending,resolve,sync,exportBackup,importBackup};
}
