import { Crosshair, ShieldCheck } from "lucide-react";
import type { EntryExecutionPlan } from "@/app/lib/entry-execution";
import { formatPrice } from "@/app/lib/market";

import { remainingLabel, TRADE_DURATION_POLICY } from "@/app/lib/trade-duration";
import { formatMelbourneDateTime } from "@/app/lib/trading-time";

export function EntryInstructions({plan, ready, reason, now, compact = false}: {
  plan: EntryExecutionPlan; ready: boolean; reason?: string; now: number; compact?: boolean;
}) {
  const expired = now >= plan.expiresAt || plan.status === "EXPIRED";
  const title = expired ? "EXPIRED · REFRESH BEFORE ENTRY" : ready ? "READY · " + (plan.side === "LONG" ? "BUY" : "SELL") + " IN RANGE"
    : plan.status === "READY" ? "WAIT · VERIFY LIVE CHECKS" : plan.headline;
  return <section aria-label="Step-by-step entry instructions" className={"rounded-2xl border p-4 " + (ready ? "border-emerald-300/30 bg-emerald-300/[0.055]" : "border-amber-300/25 bg-amber-300/[0.045]")}>
    <p className="flex items-center gap-2 text-xs font-bold uppercase tracking-widest text-slate-400"><Crosshair className="h-4 w-4"/>Your entry instructions</p>
    <p className={"mt-2 text-base font-bold " + (ready ? "text-emerald-200" : "text-amber-200")}>{title}</p>
    <p className="mt-1.5 text-sm leading-6 text-slate-300">{expired ? "This window has ended. Refresh the analysis and require a new valid confirmation before entry." : reason || plan.reason}</p>
    <div className="mt-3 grid grid-cols-2 gap-2">
      <div className="rounded-xl bg-slate-950/40 p-2.5"><p className="text-xs text-slate-400">Watch retest zone</p><p className="mt-1 break-words font-mono text-sm text-white">{formatPrice(plan.zoneLow)}–{formatPrice(plan.zoneHigh)}</p></div>
      <div className="rounded-xl bg-slate-950/40 p-2.5"><p className="text-xs text-slate-400">{plan.side === "LONG" ? "Do not buy above" : "Do not short below"}</p><p className="mt-1 font-mono text-sm font-bold text-amber-200">{formatPrice(plan.side === "LONG" ? plan.entryHigh : plan.entryLow)}</p></div>
    </div>
    <ol className="mt-4 space-y-3">{plan.steps.slice(compact ? 1 : 0, compact ? 3 : 4).map((step, index) => <li key={index} className="flex gap-2.5 text-sm leading-6 text-slate-300"><span className="mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-white/10 font-mono text-xs text-cyan-200">{index + 1}</span><span>{step}</span></li>)}</ol>
    <p className="mt-3 border-t border-white/10 pt-3 text-xs leading-5 text-rose-200/85"><ShieldCheck className="mr-1 inline h-3.5 w-3.5"/>{plan.cancelText}</p>
    {plan.style && <p className="mt-2 text-xs text-slate-400">Typical holding horizon: {TRADE_DURATION_POLICY[plan.style].holdingGuide}. Entry expiry does not close an open trade.</p>}
    <p className="mt-2 text-xs text-slate-500">{plan.confirmationTime ? "Entry window" : "Watch window"} · {remainingLabel(plan.expiresAt, now)} · {formatMelbourneDateTime(plan.expiresAt)}</p>
  </section>;
}
