import { STYLE_CONFIG, TIMEFRAMES, type TradingStyle } from "@/app/lib/market";
export const WORKSPACE_KEY = "boma-scans:workspace:v1";
export type WorkspaceState = {symbol: string; style: TradingStyle; interval: string; entryMode: "PREFERRED" | "MARKET"; section: string};
export function parseWorkspace(raw: string | null): WorkspaceState | null {
  try {
    const value = JSON.parse(raw ?? "null");
    if (!value || !/^[A-Z0-9]{2,24}USDT$/.test(value.symbol) || !Object.hasOwn(STYLE_CONFIG,value.style)) return null;
    return {symbol:value.symbol,style:value.style,interval:TIMEFRAMES.some(frame=>frame.value === value.interval) ? value.interval : STYLE_CONFIG[value.style as TradingStyle].interval,
      entryMode:value.entryMode === "MARKET" ? "MARKET" : "PREFERRED",section:["signals-center","chart-focus","trade-manager","trade-journal","opportunities","shortlist"].includes(value.section) ? value.section : "chart-focus"};
  } catch {return null;}
}
export function scanIsDue(lastAt: number | null, intervalMs: number, now: number) {
  return !lastAt || now - lastAt >= intervalMs;
}

// Integrity check detects interrupted/corrupt storage, not an authentication mechanism.
function checksum(text:string) {let value=2166136261;for(let i=0;i<text.length;i++) value=Math.imul(value^text.charCodeAt(i),16777619);return (value>>>0).toString(16);}
export const SCAN_CACHE_KEY="boma-scans:scan-cache:v1";
export function saveScanCache(value:unknown) {const payload=JSON.stringify(value);return JSON.stringify({payload,checksum:checksum(payload)});}
export function readScanCache(raw:string|null) {
  try {
    if(!raw || raw.length>4_000_000) return null;
    const outer=JSON.parse(raw);if(typeof outer.payload!=="string" || checksum(outer.payload)!==outer.checksum) return null;
    const value=JSON.parse(outer.payload);
    if(!Number.isFinite(value.at)||typeof value.scope!=="string"||!Array.isArray(value.rows)||!value.rows.length||!value.rows.every((row:Record<string,unknown>)=>row && typeof row.symbol==="string" && row.executionPlan && Array.isArray(row.entryChecks) && Array.isArray(row.takeProfits))) return null;
    return value as {at:number;scope:string;rows:import("@/app/lib/market").ScannerRow[]};
  }catch{return null;}
}
