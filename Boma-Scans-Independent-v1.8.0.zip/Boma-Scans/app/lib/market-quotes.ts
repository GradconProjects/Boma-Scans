export type LiveMarketQuote = {
  price: number; priceText: string; updatedAt: number;
  markPrice: number; markText: string; markUpdatedAt: number;
  eventAt: number; source: "STREAM" | "POLL";
};
export const QUOTE_STALE_MS = 15_000;
const decimal = (value: unknown) => typeof value === "string" && /^\d+(?:\.\d+)?$/.test(value) && Number.isFinite(Number(value)) && Number(value) > 0 ? value
  : typeof value === "number" && Number.isFinite(value) && value > 0 ? String(value) : null;

/** Delta fields are independent. A mark-only tick never substitutes for Last Price. */
export function mergeMarketQuote(previous: LiveMarketQuote | undefined, raw: Record<string, unknown>, at: number, source: LiveMarketQuote["source"]): LiveMarketQuote | undefined {
  if (!Number.isFinite(at) || at <= 0 || (previous && at < previous.eventAt)) return previous;
  const priceText = decimal(raw.lastPriceText ?? raw.lastPrice);
  const markText = decimal(raw.markPriceText ?? raw.markPrice);
  if ((!previous && !priceText) || (!priceText && !markText)) return previous;
  return {
    price: priceText ? Number(priceText) : previous!.price,
    priceText: priceText ?? previous!.priceText,
    updatedAt: priceText ? at : previous!.updatedAt,
    markPrice: markText ? Number(markText) : previous?.markPrice ?? 0,
    markText: markText ?? previous?.markText ?? "—",
    markUpdatedAt: markText ? at : previous?.markUpdatedAt ?? 0,
    eventAt: at, source: priceText ? source : previous!.source,
  };
}
export function quoteIsFresh(quote: LiveMarketQuote | undefined, now: number) {
  return Boolean(quote && quote.price > 0 && now >= quote.updatedAt - 1000 && now - quote.updatedAt <= QUOTE_STALE_MS);
}
