export const TRADING_TIME_ZONE = "Australia/Melbourne";

const dateTime = new Intl.DateTimeFormat("en-AU", {
  timeZone: TRADING_TIME_ZONE, day:"2-digit", month:"short", year:"numeric",
  hour:"2-digit", minute:"2-digit", hourCycle:"h23", timeZoneName:"short",
});
const clock = new Intl.DateTimeFormat("en-AU", {
  timeZone: TRADING_TIME_ZONE, hour:"2-digit", minute:"2-digit", second:"2-digit",
  hourCycle:"h23", timeZoneName:"short",
});
const chartClock = new Intl.DateTimeFormat("en-AU", {
  timeZone: TRADING_TIME_ZONE, day:"2-digit", month:"short", hour:"2-digit", minute:"2-digit", hourCycle:"h23",
});
const wallParts = new Intl.DateTimeFormat("en-CA", {
  timeZone: TRADING_TIME_ZONE, year:"numeric", month:"2-digit", day:"2-digit",
  hour:"2-digit", minute:"2-digit", hourCycle:"h23",
});

export const formatMelbourneDateTime = (time: number) => dateTime.format(time);
export const formatMelbourneClock = (time: number) => clock.format(time);
export const formatMelbourneChartTime = (time: number) => chartClock.format(time);

export function melbourneDateTimeInput(time: number) {
  const parts = Object.fromEntries(wallParts.formatToParts(time).map(part => [part.type, part.value]));
  return `${parts.year}-${parts.month}-${parts.day}T${parts.hour}:${parts.minute}`;
}
export const melbourneDateKey = (time: number) => melbourneDateTimeInput(time).slice(0, 10);

/** Convert a Melbourne wall time without depending on the device/browser zone.
 * DST gaps are invalid; repeated hours require the user to choose an occurrence.
 */
export function parseMelbourneDateTime(value: string, occurrence?: "earlier" | "later") {
  const empty = {timestamp: null as number | null, candidates: [] as number[], error:"Enter a valid Melbourne date and time."};
  if (!/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}$/.test(value)) return empty;
  const wall = Date.parse(value + ":00Z");
  if (!Number.isFinite(wall) || new Date(wall).toISOString().slice(0,16) !== value) return empty;
  const offsets = new Set([-36,0,36].map(hours => {
    const sample = wall + hours * 3_600_000;
    return Date.parse(melbourneDateTimeInput(sample) + ":00Z") - sample;
  }));
  const candidates = [...offsets].map(offset => wall - offset)
    .filter(time => melbourneDateTimeInput(time) === value).sort((a,b) => a-b);
  if (!candidates.length) return {...empty, error:"This Melbourne time does not exist during the daylight-saving clock change. Check the recorded time."};
  if (candidates.length > 1 && !occurrence) return {timestamp:null, candidates, error:"This Melbourne time occurs twice. Choose the first or second occurrence below."};
  return {timestamp: occurrence === "later" ? candidates[candidates.length-1] : candidates[0], candidates, error:""};
}
