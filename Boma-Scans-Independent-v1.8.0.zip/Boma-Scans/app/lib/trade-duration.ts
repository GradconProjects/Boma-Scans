import type { TradingStyle } from "@/app/lib/market";

const MINUTE = 60_000;
const HOUR = 60 * MINUTE;
export const TRADE_DURATION_POLICY: Record<TradingStyle, {
  entryWindowMs: number; confirmationCandles: number; watchWindowMs: number;
  reviewAfterMs: number; holdingGuide: string;
}> = {
  SCALP: {entryWindowMs:15*MINUTE, confirmationCandles:3, watchWindowMs:HOUR, reviewAfterMs:90*MINUTE, holdingGuide:"5–90 minutes"},
  DAY: {entryWindowMs:HOUR, confirmationCandles:4, watchWindowMs:6*HOUR, reviewAfterMs:12*HOUR, holdingGuide:"1–12 hours"},
  SWING: {entryWindowMs:4*HOUR, confirmationCandles:4, watchWindowMs:24*HOUR, reviewAfterMs:72*HOUR, holdingGuide:"1–3 days"},
  POSITION: {entryWindowMs:24*HOUR, confirmationCandles:6, watchWindowMs:72*HOUR, reviewAfterMs:14*24*HOUR, holdingGuide:"3–14 days"},
};

/** Faster custom chart frames shorten the window; a slower frame cannot extend its style cap. */
export function entryWindowMs(style: TradingStyle, intervalMs?: number) {
  const policy = TRADE_DURATION_POLICY[style];
  return intervalMs && intervalMs > 0
    ? Math.min(policy.entryWindowMs, intervalMs * policy.confirmationCandles)
    : policy.entryWindowMs;
}

export function durationLabel(ms: number) {
  if (ms >= 86_400_000 && ms % 86_400_000 === 0) return ms / 86_400_000 + "d";
  if (ms >= HOUR && ms % HOUR === 0) return ms / HOUR + "h";
  return Math.round(ms / MINUTE) + "m";
}

export function remainingLabel(deadline: number, now: number) {
  const seconds = Math.max(0, Math.ceil((deadline - now) / 1000));
  if (!seconds) return "Expired";
  const days = Math.floor(seconds / 86400);
  const hours = Math.floor(seconds % 86400 / 3600);
  const minutes = Math.floor(seconds % 3600 / 60);
  if (days) return days + "d " + hours + "h " + minutes + "m left";
  if (hours) return hours + "h " + minutes + "m left";
  return minutes + "m " + (seconds % 60) + "s left";
}

export function scanEntryExpiresAt(row: {style: TradingStyle; analyzedAt: number; executionPlan?: {expiresAt: number}}) {
  return Math.min(row.executionPlan?.expiresAt ?? row.analyzedAt, row.analyzedAt + entryWindowMs(row.style));
}
