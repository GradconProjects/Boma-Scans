import { parseStoredTrades, type TrackedTrade } from "@/app/lib/trade-manager";
export type JournalRecord = {trade: TrackedTrade; revision: number};
export type PendingTrade = {trade: TrackedTrade; base: number};
export type JournalState = {owner: string; records: Record<string, JournalRecord>; pending: Record<string, PendingTrade>; conflicts: Record<string, JournalRecord>};
export const emptyJournal = (owner: string): JournalState => ({owner,records:{},pending:{},conflicts:{}});
export const sameTrade = (a: TrackedTrade, b: TrackedTrade) => JSON.stringify(a) === JSON.stringify(b);
export function validTrade(value: unknown): value is TrackedTrade {
  if (!value || typeof value !== "object") return false;
  const trade = value as TrackedTrade;
  if (typeof trade.id !== "string" || !/^[a-zA-Z0-9:_-]{1,160}$/.test(trade.id) || !/^[A-Z0-9]{2,24}USDT$/.test(trade.symbol) ||
      !["PAPER","MANUAL_LIVE"].includes(trade.mode) || !["LONG","SHORT"].includes(trade.side) || !["SCALP","DAY","SWING","POSITION"].includes(trade.style) || !["OPEN","CLOSED"].includes(trade.status)) return false;
  if (![trade.entryPrice,trade.quantity,trade.leverage,trade.stop,trade.initialStop,trade.openedAt,trade.tp1,trade.tp2,trade.tp3,trade.tp4,trade.tp5].every(n=>Number.isFinite(n)&&n>0) || !Number.isFinite(trade.remainingPct) || trade.remainingPct<0 || trade.remainingPct>100 || !Number.isFinite(trade.realizedPnl)) return false;
  try {return parseStoredTrades(JSON.stringify([trade])).length===1;} catch {return false;}
}
export function journalTrades(state: JournalState) {
  const result = Object.fromEntries(Object.entries(state.records).map(([id,row])=>[id,row.trade]));
  for (const [id,row] of Object.entries(state.pending)) result[id]=row.trade;
  return Object.values(result).sort((a,b)=>b.openedAt-a.openedAt);
}
export function queueTrades(state: JournalState, trades: TrackedTrade[]): JournalState {
  const pending = {...state.pending};
  for (const trade of trades) {
    const previous = pending[trade.id]?.trade ?? state.records[trade.id]?.trade;
    if (!previous || !sameTrade(previous,trade)) pending[trade.id]={trade,base:pending[trade.id]?.base ?? state.records[trade.id]?.revision ?? 0};
  }
  return {...state,pending};
}
export function mergeJournal(state: JournalState, rows: JournalRecord[]): JournalState {
  const records = {...state.records}, pending = {...state.pending}, conflicts = {...state.conflicts};
  for (const remote of rows) {
    const id = remote.trade.id;
    if ((records[id]?.revision ?? 0) > remote.revision) continue;
    records[id]=remote;
    if (pending[id]) {
      if (sameTrade(pending[id].trade,remote.trade)) {delete pending[id];delete conflicts[id];}
      else if (remote.revision !== pending[id].base) conflicts[id]=remote;
    }
  }
  return {...state,records,pending,conflicts};
}
/** A local edit made during an in-flight save must survive its acknowledgement. */
export function acknowledgeTrade(state: JournalState, sent: PendingTrade, remote: JournalRecord): JournalState {
  const id = remote.trade.id;
  const pending = {...state.pending}, conflicts = {...state.conflicts};
  if (pending[id] && sameTrade(pending[id].trade,sent.trade)) delete pending[id];
  else if (pending[id]) pending[id]={...pending[id],base:remote.revision};
  delete conflicts[id];
  return {...state,records:{...state.records,[id]:remote},pending,conflicts};
}
export function resolveJournalConflict(state: JournalState,id: string,useLocal: boolean): JournalState {
  const remote=state.conflicts[id];if (!remote) return state;
  const pending={...state.pending},conflicts={...state.conflicts};
  if (useLocal && pending[id]) pending[id]={...pending[id],base:remote.revision};else delete pending[id];
  delete conflicts[id];return {...state,pending,conflicts};
}
export function restoreJournal(raw: string | null,owner: string): JournalState {
  try {
    const state=JSON.parse(raw??"null") as JournalState;
    if (!state || state.owner!==owner || !state.records || !state.pending || !state.conflicts) return emptyJournal(owner);
    for (const [id,row] of Object.entries(state.records)) if (!validTrade(row.trade) || id!==row.trade.id || !Number.isInteger(row.revision) || row.revision<1) return emptyJournal(owner);
    for (const [id,row] of Object.entries(state.pending)) if (!validTrade(row.trade) || id!==row.trade.id || !Number.isInteger(row.base) || row.base<0) return emptyJournal(owner);
    for (const [id,row] of Object.entries(state.conflicts)) if (!validTrade(row.trade) || id!==row.trade.id || !Number.isInteger(row.revision) || row.revision<1) return emptyJournal(owner);
    return state;
  } catch {return emptyJournal(owner);}
}
