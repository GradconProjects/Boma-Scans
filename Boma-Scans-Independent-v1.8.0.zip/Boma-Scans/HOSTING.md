# Host Boma Scans in your own Cloudflare account

This project runs independently of ChatGPT. You need a Cloudflare account, Node.js 22.13 or newer, and pnpm 11.25.0. You can start on the generated workers.dev address; a custom domain is optional. Review Cloudflare's current limits/pricing before deployment.

## 1. Install and authenticate

Unzip the project and open a terminal in the `Boma-Scans` directory:

```sh
npm install -g pnpm@11.25.0
pnpm install --frozen-lockfile
pnpm exec wrangler login
```

The login opens Cloudflare in your browser. Never paste Cloudflare tokens or your owner password into a chat, source file or Git repository.

## 2. Create your journal database

```sh
pnpm exec wrangler d1 create boma-scans-journal
```

Cloudflare returns a database ID. Edit `wrangler.jsonc` and replace `REPLACE_WITH_YOUR_DATABASE_ID` with that exact ID. Keep the binding name `DB`. This database belongs to your Cloudflare account; it is separate from the ChatGPT-hosted journal.

## 3. Set your private owner password

Choose a unique password of at least 32 characters (a password manager can generate it). Run:

```sh
pnpm exec wrangler secret put BOMA_SYNC_SECRET
```

Paste the password only at Wrangler's hidden prompt. If Wrangler asks to create the `boma-scans` Worker, accept. Use that same owner password on your own devices at `/login`. Rotating this secret signs out existing sessions without deleting trades.

## 4. Deploy

```sh
pnpm typecheck
pnpm test
pnpm deploy
```

The deploy command builds the app, applies the included database migration, and publishes it. Open the returned `https://boma-scans.<your-subdomain>.workers.dev` URL, then `/login`. HTTPS is required for the secure sign-in cookie. The app does not trust user-supplied ChatGPT identity headers on this independent host.

Open the same URL on your phone and computer, sign in with the owner password, then check the trade manager for **Cloud synced**. Changes synchronize while the app is open and online. A closed mobile browser cannot run continuous market scans or sound notifications.

To add your own domain, open your Worker in Cloudflare → Settings → Domains & Routes → Add → Custom Domain. Use a domain you control in Cloudflare. No domain is required to start.

## 5. Move existing trade records

On the old site, open Trade manager → **Export trade backup**. On the new site, sign in and choose **Import backup**. New trade IDs are imported; existing IDs are left unchanged. If trades exist only on another phone/browser, open the updated old site there first so it can upload those local records, or export a backup directly on that device.

Do not clear browser storage while the journal says changes are waiting to sync. Before changing hosts, export a backup even if cloud sync is working.

## Updates and automatic deployment

Keep your real database ID in your private repository's `wrangler.jsonc`. The included GitHub Actions workflow deploys pushes to `main` after configuration. Set `CLOUDFLARE_API_TOKEN` and `CLOUDFLARE_ACCOUNT_ID` as GitHub repository secrets; the token needs the appropriate Workers deployment and D1 migration permissions. Keep `BOMA_SYNC_SECRET` as a Cloudflare Worker secret.

Every build creates the in-app source ZIP automatically. The packager excludes credentials, local journals, database files, dependencies, build output and earlier ZIPs. Keep secrets in Cloudflare, never in application source.

Technical references:
- https://developers.cloudflare.com/workers/wrangler/commands/
- https://developers.cloudflare.com/d1/wrangler-commands/
- https://developers.cloudflare.com/workers/configuration/secrets/

No OpenAI or Bybit private API key is required. This edition provides advisory and paper/manual tracking; it does not execute exchange orders.
