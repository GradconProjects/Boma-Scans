import test from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import path from "node:path";
import {fileURLToPath} from "node:url";
import Module,{createRequire} from "node:module";
import {DatabaseSync} from "node:sqlite";
import ts from "typescript";
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),"..");
const require=createRequire(import.meta.url),modules=new Map();
const sqlite=new DatabaseSync(":memory:");
sqlite.exec(readFileSync(path.join(root,"drizzle/0000_skinny_black_bolt.sql"),"utf8"));
const DB={prepare(sql){let args=[];return {bind(...values){args=values;return this;},async first(){return sqlite.prepare(sql).get(...args)??null;},async all(){return {results:sqlite.prepare(sql).all(...args)};},async run(){return sqlite.prepare(sql).run(...args);}};}};
let owner="alice";
function load(relative){const file=path.join(root,relative);if(modules.has(file))return modules.get(file).exports;const module=new Module(file);modules.set(file,module);module.require=spec=>spec==="cloudflare:workers"?{env:{DB}}:spec==="@/app/server/journal-auth"?{journalOwner:async()=>owner,journalLoginUrl:"/login"}:spec.startsWith("@/")?load(spec.slice(2)+".ts"):require(spec);module._compile(ts.transpileModule(readFileSync(file,"utf8"),{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2022}}).outputText,file);return module.exports;}
const sync=load("app/lib/journal-sync.ts"),manager=load("app/lib/trade-manager.ts"),api=load("app/api/journal/route.ts"),workspace=load("app/lib/workspace-state.ts"),sessions=load("app/lib/owner-session.ts");
const makeTrade=()=>manager.createTrackedTrade({symbol:"ETHUSDT",side:"LONG",mode:"PAPER",style:"DAY",entryPrice:100,quantity:1,leverage:5,stop:99,tp1:101,tp2:102,tp3:103,tp4:104,tp5:105,atrAtEntry:1});
const put=(trade,base,origin="https://boma.test")=>api.PUT(new Request("https://boma.test/api/journal",{method:"PUT",headers:{origin,"content-type":"application/json"},body:JSON.stringify({trade,base,owner})}));

test("Cloud journal is private, durable, idempotent and detects concurrent device edits",async()=>{
 const trade=makeTrade();owner=null;
 assert.equal((await api.GET(new Request("https://boma.test/api/journal"))).status,401);
 assert.equal((await put(trade,0)).status,401);
 owner="alice";
 assert.equal((await put(trade,0,"https://evil.test")).status,403);
 const first=await put(trade,0);assert.equal(first.status,200);assert.equal((await first.json()).record.revision,1);
 assert.equal((await put(trade,0)).status,200,"Retry must not create another record");
 const [one,two]=await Promise.all([put({...trade,remainingPct:80},1),put({...trade,remainingPct:60},1)]);
 assert.deepEqual([one.status,two.status].sort(),[200,409]);
 const stored=await (await api.GET(new Request("https://boma.test/api/journal"))).json();assert.equal(stored.records.length,1);assert.equal(stored.records[0].revision,2);
 owner="bob";assert.equal((await (await api.GET(new Request("https://boma.test/api/journal"))).json()).records.length,0);
 assert.equal((await put({...trade,remainingPct:40},2)).status,409,"Cannot update another owner's row");
 owner="alice";assert.equal((await put({...trade,quantity:-1},2)).status,400);
});

test("Offline changes survive reload and stale remote data cannot reopen a locally closed trade",()=>{
 const trade=makeTrade();let state=sync.mergeJournal(sync.emptyJournal("alice"),[{trade,revision:1}]);
 state=sync.queueTrades(state,[{...trade,status:"CLOSED",remainingPct:0}]);
 state=sync.restoreJournal(JSON.stringify(state),"alice");assert.equal(sync.journalTrades(state)[0].status,"CLOSED");
 state=sync.mergeJournal(state,[{trade:{...trade,remainingPct:80},revision:2}]);assert.equal(sync.journalTrades(state)[0].status,"CLOSED");assert.equal(Object.keys(state.conflicts).length,1);
 const cloud=sync.resolveJournalConflict(state,trade.id,false);assert.equal(sync.journalTrades(cloud)[0].remainingPct,80);
 const local=sync.resolveJournalConflict(state,trade.id,true);assert.equal(local.pending[trade.id].base,2);assert.equal(local.pending[trade.id].trade.status,"CLOSED");
 assert.equal(sync.journalTrades(sync.restoreJournal(JSON.stringify(state),"bob")).length,0);
});

test("An edit made while a save is in flight remains queued against the acknowledged revision",()=>{
 const trade=makeTrade();let state=sync.queueTrades(sync.emptyJournal("alice"),[trade]);const sent=state.pending[trade.id];
 state=sync.queueTrades(state,[{...trade,remainingPct:80}]);
 state=sync.acknowledgeTrade(state,sent,{trade,revision:1});assert.equal(state.pending[trade.id].trade.remainingPct,80);assert.equal(state.pending[trade.id].base,1);
 state=sync.acknowledgeTrade(state,state.pending[trade.id],{trade:{...trade,remainingPct:80},revision:2});assert.equal(Object.keys(state.pending).length,0);
});

test("Mobile selection and scan schedule restore without treating focus as a scan trigger",()=>{
 const state=workspace.parseWorkspace(JSON.stringify({symbol:"SOLUSDT",style:"SCALP",interval:"1",entryMode:"MARKET",section:"chart-focus"}));assert.equal(state.symbol,"SOLUSDT");assert.equal(state.interval,"1");
 assert.equal(workspace.parseWorkspace("broken"),null);
 assert.equal(workspace.scanIsDue(1_000_000,900_000,1_001_000),false);assert.equal(workspace.scanIsDue(1_000_000,900_000,1_900_000),true);
 const cache=workspace.saveScanCache({at:1_000_000,scope:"SCALP:STRICT",rows:[{symbol:"SOLUSDT",executionPlan:{},entryChecks:[],takeProfits:[]}]});assert.equal(workspace.readScanCache(cache).rows[0].symbol,"SOLUSDT");assert.equal(workspace.readScanCache(cache.replace("SOLUSDT","BTCUSDT")),null);
});

test("Independent owner sessions reject tampering, wrong secrets and expired cookies",async()=>{
 const secret="test-only-"+"a".repeat(40),now=Date.now();const token=await sessions.createOwnerSession(secret,now);
 assert.equal(await sessions.validOwnerSession(token,secret,now),true);
 assert.equal(await sessions.validOwnerSession(token,secret+"b",now),false);
 assert.equal(await sessions.validOwnerSession(token.replace(/^\d/,"9"),secret,now),false);
 assert.equal(await sessions.validOwnerSession(token,secret,now+31*86_400_000),false);
 assert.equal(await sessions.equalSecret(secret,secret),true);assert.equal(await sessions.equalSecret(secret,"wrong"),false);
});
