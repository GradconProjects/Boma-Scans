import { integer, primaryKey, sqliteTable, text } from "drizzle-orm/sqlite-core";
export const journal = sqliteTable("trade_journal", {
  owner: text("owner").notNull(), id: text("id").notNull(),
  revision: integer("revision").notNull(), data: text("data").notNull(),
  updatedAt: integer("updated_at").notNull(),
}, table => [primaryKey({columns:[table.owner,table.id]})]);
export const loginAttempts = sqliteTable("login_attempts", {
  key: text("key").primaryKey(), attempts: integer("attempts").notNull(), expiresAt: integer("expires_at").notNull(),
});
