# Workspace persistence and journal sync

The selected pair, trading mode, chart interval, entry tab and active section are saved on the device. Recent completed scan results are restored as reference-only; cached analysis never grants fresh entry approval. Tab focus no longer triggers a scan. Automatic scanning follows its configured interval while visible. An overdue scheduled scan can run when returning, but does not change the selected pair. Closed/suspended mobile apps cannot keep a browser scanner running continuously.

The hosted journal uses private Cloudflare D1 rows scoped to the authenticated ChatGPT account. Open the same site with the same account on all devices. Original device-only trades migrate when that device opens the updated app. Devices poll the journal every 10 seconds while visible and reconnect on return/online. Edits are queued locally, then sent with the previous record revision. Conflicts require a choice; lost acknowledgements are safe to retry. Pending edits are retained through reload and do not replace newer cloud changes silently. Cloud synchronization requires connectivity; the status indicator reports pending or failed saves.

The database does not open, modify or close exchange orders. Records describe paper and manually tracked trades. A cloud position record is not proof of a Bybit fill.

Independent hosting uses a separate database and an owner password, never unverified ChatGPT headers. Export the trade backup from the old host and import it into the new host. Existing IDs are preserved and duplicate imports do not overwrite existing records. Local cache and stored notifications remain device-specific; the trade journal is shared.

The Host / Download page serves a versioned ZIP from the app's own origin. The service worker never caches journal API responses, sign-in routes or downloadable ZIPs. If an embedded mobile browser blocks downloads, open the hosting page in Safari or Chrome.

Validation: journal route tests run against real SQLite with a test-only identity adapter. They cover authentication, origin checks, owner isolation, compare-and-swap conflicts, invalid records and idempotent retries. Client state tests cover offline queues, reloads and edits during an in-flight save. Owner-cookie tests cover wrong secrets, tampering and expiry. These are automated checks, not a claim that two physical devices were tested.
