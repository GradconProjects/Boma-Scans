# Melbourne time, live quotes and setup visibility

All visible clocks use Australia/Melbourne, including AEST/AEDT changes. Candle epoch timestamps and exchange candle boundaries remain unchanged. Manual position times are interpreted in Melbourne; nonexistent daylight-saving times are rejected, and repeated times require the user to choose an occurrence. Daily portfolio P&L resets at Melbourne midnight.

## Entry validity and holding horizon

| Mode | Default frame | Entry window after confirmation closes | Watch horizon | Holding guide |
| --- | --- | --- | --- | --- |
| Scalp | 5 minutes | Up to 15 minutes | 1 hour | 5–90 minutes |
| Day | 15 minutes | Up to 1 hour | 6 hours | 1–12 hours |
| Swing | 1 hour | Up to 4 hours | 24 hours | 1–3 days |
| Position | 4 hours | Up to 24 hours | 72 hours | 3–14 days |

Entry windows are the smaller of the mode limit and its confirmation-candle count multiplied by the chart frame. A repeated quote, copy or refresh of the same confirmation does not renew expiry. Fresh structure, stop, live price and other entry checks can cancel earlier. Watch windows are conditional monitoring horizons, not entry approval. New confirmed structure can establish a new plan. Holdings receive separate management reviews; entry expiry does not close an open position. These policy horizons are not backtested optimal holding times.

## Seeing all setups

All setups is the default view. Every analyzed pair remains visible with its grade, relative risk and Ready / Waiting / Recheck / Expired / Blocked status. Expand a row for instructions, target evidence and BTC context. Ready signals remains a separate list of qualified plans, alongside saved Notifications. Rows are shown progressively and retained during refresh; changing mode only shows matching mode and flexibility results. Missing-data markets remain ungraded in Market opportunities. No grade or opportunity is fabricated when Bybit is unavailable.

## Bybit price semantics

Current list prices and the chart header use Last Price from Bybit USDT linear perpetuals. Mark Price is shown separately. Decimal strings are preserved. This must be compared with Bybit's same perpetual contract and Last Price display, not Spot, Index or Mark.

WebSocket ticker snapshots initialize per-symbol state; deltas preserve absent fields. Mark-only messages do not change Last Price or its timestamp. Older events and invalid prices are ignored. Bybit REST tickers refresh every five seconds as a fallback, without cache; a slower REST response cannot overwrite a newer exchange event. Rendering batches updates at 250 ms. Quotes older than 15 seconds show STALE and cannot qualify a ready list entry. Real networks, exchange delivery, local clock differences and sleeping browser tabs introduce latency; zero delay is not guaranteed.

The technical scan runs separately from quotes. Frozen target/entry levels are not rebranded as current prices. Fresh prices outside a confirmed range withdraw ready status immediately when rendered. Confirmation still rechecks the selected chart and portfolio. The trade manager explicitly uses Mark Price for estimated P&L and liquidation-distance monitoring, while separately displaying Last Price; actual execution depends on fills.

## Validation

34 engine regression tests cover directional entries, no-chase protection, targets, leverage, original alert persistence, mode windows, Melbourne DST and midnight, exact quote precision, out-of-order and mark-only deltas, stale quotes and visible waiting/blocked setups. Static type checking and production builds are also required. These checks establish software behavior, not profitability or a verified live exchange connection from this development environment.

Protocol references: [Bybit ticker WebSocket](https://bybit-exchange.github.io/docs/v5/websocket/public/ticker), [Bybit REST tickers](https://bybit-exchange.github.io/docs/v5/market/tickers), [Intl.DateTimeFormat](https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Intl/DateTimeFormat).
