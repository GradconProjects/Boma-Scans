declare namespace Cloudflare {
  interface Env {
    DB?: D1Database;
    BOMA_SYNC_SECRET?: string;
    BUCKET?: R2Bucket;
  }
}
