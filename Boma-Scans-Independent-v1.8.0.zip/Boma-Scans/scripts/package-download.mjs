// Portable source ZIP, generated before each independent build. No secrets or data.
import {readFile,readdir,mkdir,writeFile} from "node:fs/promises";
import path from "node:path";
import {deflateRawSync} from "node:zlib";
const root=process.cwd(),pkg=JSON.parse(await readFile(path.join(root,"package.json"),"utf8"));
if(pkg.name!=="boma-scans") throw new Error("Run this script from the independent Boma-Scans project.");
const directories=["app","components","hooks","lib","db","drizzle","docs","public","tests","vendor","scripts",".github"];
const files=["package.json","pnpm-lock.yaml","pnpm-workspace.yaml","README.md","HOSTING.md","VERSION","components.json","cloudflare-env.d.ts","eslint.config.mjs","next-env.d.ts","next.config.ts","postcss.config.mjs","tsconfig.json","vite.config.ts","wrangler.jsonc"];
async function walk(relative) {
  let entries;try{entries=await readdir(path.join(root,relative),{withFileTypes:true});}catch{return;}
  for(const entry of entries){
    if(entry.name.startsWith(".") || ["node_modules","dist","downloads"].includes(entry.name)) continue;
    const name=relative+"/"+entry.name;
    if(entry.isDirectory()) await walk(name);
    else if(entry.isFile() && /\.(tsx?|jsx?|mjs|cjs|jsonc?|ya?ml|css|md|sql|svg|png|jpe?g|webp|ico|webmanifest|woff2?|txt)$/.test(entry.name)) files.push(name);
  }
}
for(const directory of directories) await walk(directory);
const table=Array.from({length:256},(_,n)=>{let c=n;for(let i=0;i<8;i++)c=c&1?0xedb88320^(c>>>1):c>>>1;return c>>>0;});
const crc=buffer=>{let c=0xffffffff;for(const byte of buffer)c=table[(c^byte)&255]^(c>>>8);return (c^0xffffffff)>>>0;};
const chunks=[],central=[];let offset=0,count=0;
for(const file of [...new Set(files)].sort()){
  let bytes;try{bytes=await readFile(path.join(root,file));}catch(error){if(error.code==="ENOENT")continue;throw error;}
  const name=Buffer.from("Boma-Scans/"+file),compressed=deflateRawSync(bytes),checksum=crc(bytes);
  const local=Buffer.alloc(30);local.writeUInt32LE(0x04034b50);local.writeUInt16LE(20,4);local.writeUInt16LE(0x800,6);local.writeUInt16LE(8,8);local.writeUInt16LE(33,12);local.writeUInt32LE(checksum,14);local.writeUInt32LE(compressed.length,18);local.writeUInt32LE(bytes.length,22);local.writeUInt16LE(name.length,26);
  chunks.push(local,name,compressed);
  const header=Buffer.alloc(46);header.writeUInt32LE(0x02014b50);header.writeUInt16LE(20,4);header.writeUInt16LE(20,6);header.writeUInt16LE(0x800,8);header.writeUInt16LE(8,10);header.writeUInt16LE(33,14);header.writeUInt32LE(checksum,16);header.writeUInt32LE(compressed.length,20);header.writeUInt32LE(bytes.length,24);header.writeUInt16LE(name.length,28);header.writeUInt32LE(offset,42);
  central.push(header,name);offset+=local.length+name.length+compressed.length;count++;
}
const directory=Buffer.concat(central),end=Buffer.alloc(22);end.writeUInt32LE(0x06054b50);end.writeUInt16LE(count,8);end.writeUInt16LE(count,10);end.writeUInt32LE(directory.length,12);end.writeUInt32LE(offset,16);
const destination=path.join(root,"public/downloads/Boma-Scans-Independent-v"+pkg.version+".zip");
await mkdir(path.dirname(destination),{recursive:true});await writeFile(destination,Buffer.concat([...chunks,directory,end]));
console.log("Download prepared: "+path.basename(destination)+" ("+count+" files; excludes credentials, build output and journals)");
