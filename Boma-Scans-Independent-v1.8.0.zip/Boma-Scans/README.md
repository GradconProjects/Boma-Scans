# Boma Scans

Boma Scans is an independently deployable Bybit market scanner, technical-analysis dashboard, charting tool, and manual trade-management assistant. This edition does not require ChatGPT hosting or an OpenAI API key.

## Hosting and cross-device sync (1.8)

Start with **[HOSTING.md](HOSTING.md)** to host in your Cloudflare account. This version adds a private journal database and owner-password sign-in at `/login`. Sign in on each device to sync paper and manually tracked trades. It does not rely on ChatGPT account headers or an OpenAI API key.

Your selected pair and chart timeframe survive mobile reloads. Returning to the tab does not itself trigger a full scan. Recent scans restore as reference-only until rechecked. The journal has offline retry and explicit conflict resolution. Export/import backups can move your records from the previous host. Local records cannot appear on other devices until the original device opens the updated app and uploads them.

## Live prices, Melbourne time and setup durations (1.7)

Open **All setups** for every analyzed pair and its grade; use **Ready** for qualified plans, or **Notifications** for saved Telegram-style signals. Expand a pair for exact entry steps. Previous results remain visible during a scan.

Prices update independently of analysis using Bybit USDT perpetual **Last Price**, preserving exchange precision. **Mark Price** is labeled separately. Old or missing quotes are marked stale and cannot authorize a new ready signal. Network latency still exists.

Every clock uses Melbourne time, including daylight saving. Default entry windows after a closed confirmation are **15 minutes scalp, 1 hour day, 4 hours swing, and 24 hours position**. The countdown and Melbourne expiry appear with the instructions. A failed entry check cancels sooner. Entry expiry and holding horizons are separate; existing trades continue under position management.

See [price and timing details](docs/LIVE-PRICES-AND-TIMING.md) for all mode horizons, quote freshness, daylight saving and validation.

## What is included

- Live Bybit USDT perpetual prices through Bybit's public WebSocket feed
- Long and short market scanning
- Scalp, day, swing, and position modes
- Multi-timeframe candle analysis with up to 1,000 Bybit candles per request
- Zoomable charts with support, resistance, trendlines, entry zones, stop and five TA-derived targets
- A+–D trade grades for every scanned market, including developing and rejected setups
- Relative Low, Medium and High risk tabs with separate long/short bias filters
- Numbered entry instructions: retest zone, closed-candle trigger, permitted price range, exact BUY/SELL LIMIT, stop and cancellation
- Shared anti-chase rules for long and short entries, including close-target alternatives
- Explicit entry-proof checklist covering TA, execution quality and payoff readiness
- Rolling BTC correlation, beta, relative-strength divergence and accept/caution/reject guidance
- Medium-risk qualified shortlist and adaptive leverage suggestions
- Prominent Telegram-style signal cards with emojis, entry, stop, five targets and Copy signal
- Notifications tab with an unread badge and the last 100 setup alerts saved on this device
- Optional setup chime with enable, mute, test and volume controls
- Manual/paper position tracking with stay, exit, reduce, and add guidance
- Installable Progressive Web App (PWA)
- A same-origin market-data proxy so browser CORS restrictions do not break the scanner

## Setup-aware signal gates

### Signals and sound alerts

Open **Signals** at the top of the dashboard for qualified plans. The bell opens **Notifications**. Click **Enable sound** once in the current tab; **Test sound** plays a sample and enables alerts. Keep the app open with scanning enabled. Browser/device sleep or mute settings may suppress audio. Continuing setups are deduplicated; saved alerts show their original levels and expire visibly. **Copy signal** formats a Telegram-style message but does not send it to Telegram. See [Signal alerts](docs/SIGNAL-ALERTS.md) for behavior and limits.

Boma Scans does not apply one score threshold to every market pattern. Score thresholds remain setup-specific; version 1.6 repairs timing and stop placement:

- Confirmed pullback: 66+
- Trend continuation or breakout: 70+
- CHoCH reversal: 72+
- Add 8 points in a weak trend

Strict mode requires a confirmed retest in every trading style. Balanced can accept strong closed-candle confirmation at baseline + 6 with three structural confluences and two aligned frames. Flexible additionally accepts strong continuation/breakout at its baseline. No mode bypasses mandatory safety checks, a pump/dump retest, the permitted entry range or confirmation expiry. Stops protect the whole retest structure; overly wide stops block entry instead of being pulled inward. CHoCH's strict retest route can use one aligned execution frame with its existing structure confirmations. Spread-cost limits adapt by style from 0.14R to 0.22R.

The separate **Enter now** tab offers a current-price scenario with structural stops, close TA targets, editable fee/slippage assumptions, reduced risk and explicit ALLOW/CAUTION/AVOID reasoning. It can be unavailable when nearby structure or net payoff is inadequate. See [Entry location and retest repair](docs/ENTRY-LOCATION.md) for the current policy and limitations; it supersedes earlier timing and stop descriptions.

An entry is not approved by the setup score alone. The Entry Proof panel independently checks the setup-specific confluence threshold, confirmed structure, multi-timeframe trend, closed-candle trigger/retest, momentum, regime, participation, liquidity and spread, funding crowding, and the five-target payoff map. A visible SETUP may therefore remain WAIT until every required check passes.

## Avoid chasing an entry

Open the live chart and follow **Your entry instructions**. WAIT RETEST means wait at the numeric zone. After the specified candle closes beyond the trigger, READY authorizes only the displayed price range; follow the exact BUY LIMIT / SELL LIMIT instruction and cancellation rule. A moved price cancels entry. Neither a high score nor the close-target tab bypasses these rules.

For managed positions, a small gain or TP1 touch no longer triggers automatic breakeven advice. A suggested tighter stop needs a recorded partial and later confirmed protective structure. No open stop is widened automatically. These changes are tested mechanically, not proven to improve win rate.

## Universal grading and relative risk tabs

The scanner keeps every eligible liquid perpetual candidate available, removing the former 30-pair cap. Expand the opportunities dropdown and then any row for details. Missing-data markets remain visible as ungraded. Each analyzed market receives:

- a trade rating from 0–100 and an A+–D grade;
- a separate entry-quality grade;
- a relative Low, Medium or High risk band;
- a specific gate or risk explanation.

Low requires entry readiness, rating/entry quality ≥84, a trending regime, target reliability ≥65 and no BTC caution/rejection or override. Medium and the shortlist share rating ≥70 and entry quality ≥68, with no required failure or BTC rejection; the shortlist additionally requires complete entry/payoff gates. These are relative categories, not safety guarantees. High-risk and rejected markets remain available for comparison.

## Historical relationship to BTC

For every pair, Boma Scans aligns up to 120 closed execution-timeframe candles with BTC and calculates Pearson return correlation, beta, the recent pair and BTC moves, beta-adjusted relative strength, and a standardized residual-divergence test. The dashboard labels the relationship as tightly linked, BTC-sensitive, loosely linked, independent, or inverse.

A bullish or bearish divergence is accepted only when it agrees with the proposed trade side and pair-specific structure plus participation confirm it. A highly BTC-correlated pair receives a stricter divergence test. Low-correlation or inverse pairs can diverge more naturally, but their own entry checklist must still pass before a TAKE. Correlation is rolling and can change; it is context, not causation or a standalone signal.

## Five-level technical target engine

Target prices are not fixed percentages. Boma Scans clusters closed-candle evidence from execution, context, and macro timeframes. Inputs include swing liquidity, prior-day/week extremes, approximate OHLCV volume nodes/POC, anchored VWAP deviations, Fibonacci extensions, measured moves and candlestick projections including inside-bar and three-drive proxies. ATR fallback is restricted to outer TP4/TP5. Missing inner evidence is marked UNCONFIRMED and blocks entry rather than inventing a level.

Each TP displays its source, reward in R, confidence, and confluence. The medium-risk shortlist requires at least two structure-backed objectives and a minimum 55/100 target-quality score. Target levels re-evaluate with new closed candles and can move before entry; an open trade keeps the levels captured when tracking began.

## Important limits

Boma Scans provides decision support, not guaranteed profits. Ratings and relative risk bands rank the current evidence; they are not win probabilities. Signals, divergence verdicts, leverage suggestions, stops, and targets can be wrong. The included trade manager does not place, amend, or close orders on Bybit. It tracks positions entered manually in the app and provides guidance. Use Bybit testnet and paper trading before risking money.

Live scans require internet access and Bybit availability. The installed PWA can cache its interface, but it cannot obtain new market prices while offline.

## Fastest independent deployment: Cloudflare Workers

You own the Cloudflare account and deployment. A ChatGPT subscription is not required after deployment.

### Requirements

- Node.js 22.13 or newer
- pnpm 11.25 or newer
- A Cloudflare account

### One-time setup

```bash
corepack enable
corepack prepare pnpm@11.25.0 --activate
pnpm install --frozen-lockfile
pnpm exec wrangler login
pnpm deploy
```

Wrangler opens Cloudflare sign-in and then prints the new `workers.dev` address. Visit that address, verify the live indicator, run a scan, and install the PWA from the browser.

### Local use

```bash
pnpm install --frozen-lockfile
pnpm dev
```

Open the local address shown in the terminal. Run these checks before deploying an update:

```bash
pnpm typecheck
pnpm test
pnpm build
pnpm deploy:dry
```

### Future updates

After editing the app, run:

```bash
pnpm deploy
```

The deployment is controlled by your Cloudflare login. No OpenAI credentials are used.

## Custom domain

After the first deployment, open **Cloudflare Dashboard → Workers & Pages → boma-scans → Settings → Domains & Routes** and attach a domain or subdomain that you control.

## GitHub backup and automatic deployment

1. Create a private GitHub repository.
2. Upload this project and push the `main` branch.
3. In the repository settings, add these Actions secrets:
   - `CLOUDFLARE_ACCOUNT_ID`
   - `CLOUDFLARE_API_TOKEN`
4. The included workflow deploys every successful push to `main`.

Use a narrowly scoped Cloudflare token with Workers edit permissions. Never commit API tokens, exchange keys, seed phrases, or passwords.

## API keys

No key is required for the current Bybit public market-data scanner. An OpenAI key is not required. If authenticated Bybit order execution is added later, keep exchange credentials only in server-side Cloudflare secrets and use a restricted key with withdrawals disabled. Do not put exchange secrets in browser code, local storage, source files, or GitHub.

## Data and backups

Preferences and manually tracked trades currently live in the browser on the device where they were entered. Clearing browser data or changing devices can remove that local state. Keep this source archive and the GitHub repository as independent backups.

## Main commands

| Command | Purpose |
| --- | --- |
| `pnpm dev` | Run Boma Scans locally |
| `pnpm typecheck` | Check TypeScript errors |
| `pnpm test` | Run twenty-eight trading and notification regression tests |
| `pnpm build` | Create the production build |
| `pnpm deploy:dry` | Validate a deployment without publishing |
| `pnpm deploy` | Deploy to your Cloudflare account |

## Ownership boundary

This package contains no ChatGPT Sites project identifier, ChatGPT sign-in module, or OpenAI-hosted runtime configuration. Its external runtime dependencies are Cloudflare hosting and Bybit's public market-data services. You can move the source to another compatible host later.
